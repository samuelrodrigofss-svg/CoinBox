# CoinBox — Gerenciador e Simulador de Moedas Virtuais para Android

![CoinBox](https://img.shields.io/badge/Platform-Android_8.0%2B-brightgreen?style=flat-square)
![Language](https://img.shields.io/badge/Language-Kotlin_2.0-blue?style=flat-square)
![UI](https://img.shields.io/badge/UI-Jetpack_Compose_Material_3-purple?style=flat-square)
![Database](https://img.shields.io/badge/Database-Room_2.6-orange?style=flat-square)
![Architecture](https://img.shields.io/badge/Architecture-Clean_Architecture_%26_MVVM-red?style=flat-square)

O **CoinBox** é um aplicativo Android profissional e completo para gerenciamento, acompanhamento e simulação de saldos virtuais (moedas, gemas, diamantes, pontos, vidas, energia, créditos e dinheiro virtual) associados aos jogos e aplicativos instalados no aparelho.

---

## 1. Princípios de Segurança e Conformidade com a Google Play

O **CoinBox funciona estritamente como um livro-razão e simulador independente**.
- **Sem invasão:** NÃO modifica arquivos de terceiros, memória RAM, APKs ou servidores externos.
- **Sem violação de segurança:** Não faz bypass de autenticação ou fraude de compras no Google Play.
- **Privacidade total:** Utiliza APIs oficiais do Android (`PackageManager` com filtro `CATEGORY_LAUNCHER`) para detectar os aplicativos instalados que o usuário escolhe adicionar.
- **Armazenamento 100% Local:** Banco de dados seguro com Room SQLite interno, funcionando offline sem expor dados privados.

---

## 2. Requisitos de Desenvolvimento

- **Android Studio:** Ladybug (2024.2.1) ou versão mais recente
- **JDK:** Java 17 ou Java 21
- **Gradle:** 8.7+ (Gradle Kotlin DSL)
- **Min SDK:** 26 (Android 8.0 Oreo)
- **Target / Compile SDK:** 35 (Android 15)

---

## 3. Arquitetura do Projeto (Clean Architecture + MVVM)

O código-fonte está estruturado de acordo com as melhores práticas de Clean Architecture:

```text
android/app/src/main/java/com/coinbox/app/
├── CoinBoxApplication.kt           # Inicialização do Hilt e AdMob
├── MainActivity.kt                 # Single Activity com Navigation Compose
├── data/
│   ├── local/
│   │   ├── entity/                # Room Entities (AppEntity, WalletEntity, TransactionEntity, etc.)
│   │   ├── dao/                   # Room DAOs com Flow reativo
│   │   └── database/              # RoomDatabase com Migrations e Seeders
│   └── repository/                # Implementação dos Repositórios
├── domain/
│   ├── model/                     # Modelos puros de domínio
│   ├── repository/                # Interfaces de repositório
│   └── usecase/                   # Casos de uso (AddBalance, RemoveBalance, Simulation)
├── presentation/
│   ├── screens/                   # Telas em Jetpack Compose Material 3
│   │   ├── HomeScreen.kt          # Home com saldo total e cartões de apps
│   │   ├── AppsScreen.kt          # Lista de apps do sistema e busca em tempo real
│   │   ├── AppDetailScreen.kt     # Detalhes das moedas do app selecionado
│   │   ├── AddBalanceScreen.kt    # Adição de saldo com cálculo detalhado
│   │   ├── RemoveBalanceScreen.kt # Resgate com proteção contra saldo negativo
│   │   ├── SimulationScreen.kt    # Modo simulação sandbox (Salvar / Descartar)
│   │   ├── HistoryScreen.kt       # Livro-razão com filtros de data e busca
│   │   ├── DashboardScreen.kt     # Gráficos e estatísticas
│   │   └── SettingsScreen.kt      # Tema escuro, backup JSON e ajustes
│   ├── navigation/                # NavHost e rotas do Navigation Compose
│   └── theme/                     # Cores Material 3, Tipografia e Formas
├── ads/                           # Integração Google AdMob (Banners e Interstitials)
├── utils/                         # PackageManager oficial e exportadores (CSV/JSON/TXT)
└── di/                            # Módulos de injeção de dependência Dagger Hilt
```

---

## 4. Recursos Implementados

1. **Detecção Oficial de Aplicativos:** Lista os jogos e aplicativos do celular de forma transparente.
2. **Moedas e Ativos Flexíveis:** Suporte a Gemas, Diamantes, Moedas, Pontos, Vidas, Fichas, Energia ou ativos customizados com ícone e cotação em R$.
3. **Adição e Resgate Inteligente:** Cálculo instantâneo: `Saldo Anterior + Adicionado = Novo Saldo`.
4. **Proteção Contra Saldo Negativo:** Impede valores menores que zero (com opção de habilitar em Configurações).
5. **Modo Simulação Sandbox:** Experimente aumentos de saldo ou multiplicadores de eventos (2x, 5x, 10x) sem alterar o saldo real, com botões para **Salvar** ou **Descartar**.
6. **Histórico Completo:** Filtros por período (Hoje, 7 dias, 30 dias), aplicativo, moeda e exportação em CSV, JSON e TXT.
7. **Dashboard & Gráficos:** Distribuição visual das moedas e aplicativos mais movimentados.
8. **Backup Seguro em JSON:** Exportação e importação de backups locais sem necessidade de login.
9. **Material 3 UI:** Dark Mode e Light Mode nativos, cantos arredondados e animações fluidas.
10. **Google AdMob & Versão Premium:** Preparado com slots de anúncios de teste e arquitetura desacoplada para CoinBox PRO sem anúncios.

---

## 5. Como Executar no Android Studio

1. Abra o **Android Studio**.
2. Clique em **File > Open** e selecione a pasta `android/`.
3. Aguarde o **Gradle Sync** concluir o download dos plugins e dependências.
4. Conecte um celular Android via USB (com Depuração USB ativada) ou inicie um Emulador com Android 8.0+.
5. Clique no botão verde **Run 'app'** (`Shift + F10`).

---

## 6. Geração de APK

### Gerar APK Debug para Testes:
Execute no terminal:
```bash
./gradlew assembleDebug
```
O APK será gerado em:
`android/app/build/outputs/apk/debug/app-debug.apk`

### Gerar APK Release / AAB para a Google Play:
1. Configure as variáveis da sua Keystore no arquivo `local.properties` ou nas variáveis de ambiente:
   ```properties
   KEYSTORE_FILE=/caminho/para/sua-chave.jks
   KEYSTORE_PASSWORD=sua_senha
   KEY_ALIAS=coinbox_alias
   KEY_PASSWORD=sua_senha_chave
   ```
2. Para gerar o APK Release:
   ```bash
   ./gradlew assembleRelease
   ```
   O APK assinado será gerado em:
   `android/app/build/outputs/apk/release/app-release.apk`
3. Para gerar o Android App Bundle (.aab) para a Google Play Store:
   ```bash
   ./gradlew bundleRelease
   ```
   O arquivo estará em:
   `android/app/build/outputs/bundle/release/app-release.aab`

---

## 7. Configuração do Google AdMob

O projeto utiliza os IDs de teste padrão recomendados pela documentação do Google:
- **App ID de teste:** `ca-app-pub-3940256099942544~3347511713`
- **Banner Ad Unit ID de teste:** `ca-app-pub-3940256099942544/6300978111`

Para produção na Play Store, substitua o App ID no `AndroidManifest.xml` e no arquivo `AdMobManager.kt` pelos seus IDs registrados no console do AdMob.

---

## 8. Execução dos Testes Unitários

O projeto inclui suíte de testes unitários com JUnit e Mockito cobrindo regras de negócio (adição de saldo, prevenção de saldo negativo, e simulação):
```bash
./gradlew testDebugUnitTest
```
Os relatórios são gerados em:
`android/app/build/reports/tests/testDebugUnitTest/index.html`

---

## 9. Licença

Desenvolvido para gerenciamento inteligente e simulação de ativos virtuais. Todos os direitos reservados.
