import React, { useState } from 'react';
import { ArrowUpRight, Check, Coins, Sparkles, AlertCircle } from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

export const AddBalanceScreen: React.FC = () => {
  const {
    wallets,
    apps,
    screenParams,
    addBalance,
    goBack,
    navigate,
    settings,
  } = useCoinBox();

  const initialWalletId = screenParams.walletId || wallets[0]?.id;
  const [selectedWalletId, setSelectedWalletId] = useState<string>(initialWalletId || '');
  const [amountStr, setAmountStr] = useState<string>('1000');
  const [observation, setObservation] = useState<string>('');
  const [feedback, setFeedback] = useState<{ error?: string; success?: string } | null>(null);

  const selectedWallet = wallets.find((w) => w.id === selectedWalletId);
  const targetApp = selectedWallet ? apps.find((a) => a.id === selectedWallet.appId) : null;

  const currentBalance = selectedWallet ? selectedWallet.balance : 0;
  const addedAmount = parseFloat(amountStr) || 0;
  const newCalculatedBalance = currentBalance + addedAmount;

  const quickIncrements = [100, 500, 1000, 5000, 10000, 50000];

  const handleQuickAdd = (inc: number) => {
    setAmountStr(String(addedAmount + inc));
  };

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!selectedWallet) {
      setFeedback({ error: 'Nenhuma carteira selecionada.' });
      return;
    }

    if (isNaN(addedAmount) || addedAmount <= 0) {
      setFeedback({ error: 'Digite uma quantidade maior que zero.' });
      return;
    }

    const result = addBalance(selectedWallet.id, addedAmount, observation);
    if (result.success) {
      setFeedback({ success: result.message });
      setTimeout(() => {
        goBack();
      }, 700);
    } else {
      setFeedback({ error: result.message });
    }
  };

  return (
    <div className="space-y-4 pb-8 max-w-lg mx-auto">
      {/* Title Card */}
      <div className={`p-4 rounded-3xl border ${
        settings.darkMode
          ? 'bg-gradient-to-br from-slate-900 via-emerald-950/20 to-slate-900 border-slate-800 text-slate-100'
          : 'bg-gradient-to-br from-white via-emerald-50/50 to-white border-emerald-200 text-slate-900 shadow-sm'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <ArrowUpRight className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <h2 className="text-base font-extrabold">Adicionar Saldo</h2>
            <p className={`text-xs ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Depósito virtual para simulação e acompanhamento
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleConfirm} className="space-y-4">
        {/* Wallet Selector */}
        <div className={`p-4 rounded-2xl border ${
          settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wide block mb-2">
            Selecione a Moeda / Carteira
          </label>
          <select
            value={selectedWalletId}
            onChange={(e) => setSelectedWalletId(e.target.value)}
            className={`w-full p-3 rounded-xl text-sm font-semibold border ${
              settings.darkMode
                ? 'bg-slate-800 border-slate-700 text-slate-100'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          >
            {wallets.map((w) => {
              const a = apps.find((app) => app.id === w.appId);
              return (
                <option key={w.id} value={w.id}>
                  {w.icon} {w.name} ({a?.appName || 'App'}) - Saldo: {w.balance.toLocaleString('pt-BR')}
                </option>
              );
            })}
          </select>
        </div>

        {/* Amount Input */}
        <div className={`p-4 rounded-2xl border ${
          settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Quantidade a Adicionar
            </label>
            <span className="text-xs font-mono text-emerald-400">
              {selectedWallet?.icon} {selectedWallet?.currencyType}
            </span>
          </div>

          <div className="relative">
            <input
              type="number"
              step="any"
              min="1"
              required
              placeholder="0"
              value={amountStr}
              onChange={(e) => setAmountStr(e.target.value)}
              className={`w-full py-3.5 px-4 text-2xl font-black font-mono rounded-2xl border text-center tracking-tight focus:outline-none ${
                settings.darkMode
                  ? 'bg-slate-950 border-slate-700 text-emerald-400 focus:border-emerald-500'
                  : 'bg-slate-50 border-slate-300 text-emerald-600 focus:border-emerald-500'
              }`}
            />
          </div>

          {/* Quick Increment buttons */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 mt-3">
            {quickIncrements.map((inc) => (
              <button
                type="button"
                key={inc}
                onClick={() => handleQuickAdd(inc)}
                className={`py-1.5 text-xs font-bold rounded-xl border transition-all active:scale-95 ${
                  settings.darkMode
                    ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
                    : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                }`}
              >
                +{inc >= 1000 ? `${inc / 1000}k` : inc}
              </button>
            ))}
          </div>
        </div>

        {/* Calculation Summary Preview (Specified in Prompt 7) */}
        <div className={`p-4 rounded-2xl border ${
          settings.darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-slate-100/80 border-slate-200'
        }`}>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">
            Detalhamento da Operação
          </h3>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 font-sans">Saldo anterior:</span>
              <span className="font-bold tabular-nums">
                {currentBalance.toLocaleString('pt-BR')} {selectedWallet?.icon}
              </span>
            </div>

            <div className="flex items-center justify-between text-emerald-500">
              <span className="font-sans font-semibold">Adicionado:</span>
              <span className="font-black tabular-nums">
                +{addedAmount.toLocaleString('pt-BR')} {selectedWallet?.icon}
              </span>
            </div>

            <div className="pt-2 border-t border-slate-500/20 flex items-center justify-between text-sm">
              <span className="font-sans font-extrabold">Novo saldo resultante:</span>
              <span className="font-black tabular-nums text-emerald-400">
                {newCalculatedBalance.toLocaleString('pt-BR')} {selectedWallet?.icon}
              </span>
            </div>
          </div>
        </div>

        {/* Observation note */}
        <div className={`p-4 rounded-2xl border ${
          settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wide block mb-1">
            Observação (Opcional)
          </label>
          <input
            type="text"
            placeholder="Ex: Recompensa diária, missão passe de batalha..."
            value={observation}
            onChange={(e) => setObservation(e.target.value)}
            className={`w-full px-3 py-2.5 rounded-xl text-xs border ${
              settings.darkMode
                ? 'bg-slate-800 border-slate-700 text-slate-100'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        {/* Feedback message */}
        {feedback?.error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{feedback.error}</span>
          </div>
        )}
        {feedback?.success && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{feedback.success}</span>
          </div>
        )}

        {/* Actions */}
        <div className="pt-2 flex items-center gap-3">
          <button
            type="button"
            onClick={goBack}
            className="flex-1 py-3 px-4 rounded-2xl border text-xs font-semibold text-slate-400 hover:text-slate-200 border-slate-700"
          >
            Cancelar
          </button>

          <button
            type="submit"
            className="flex-2 py-3 px-4 rounded-2xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 hover:bg-emerald-400 shadow-lg shadow-emerald-500/20 active:scale-[0.98] transition-all"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Confirmar Depósito</span>
          </button>
        </div>
      </form>
    </div>
  );
};
