import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Star,
  CheckCircle2,
  Sparkles,
  ArrowUpDown,
  Smartphone,
  Layers,
  Filter,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

export const AppsListScreen: React.FC = () => {
  const {
    apps,
    installedDeviceApps,
    registerAppFromDevice,
    createCustomApp,
    toggleFavoriteApp,
    navigate,
    screenParams,
    settings,
  } = useCoinBox();

  const [activeTab, setActiveTab] = useState<'registered' | 'device'>(
    screenParams.tab === 'available' ? 'device' : 'registered'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | 'recent'>('asc');
  const [showAddCustomModal, setShowAddCustomModal] = useState(false);

  // New Custom App Form state
  const [customName, setCustomName] = useState('');
  const [customPkg, setCustomPkg] = useState('');
  const [customCategory, setCustomCategory] = useState('Jogos');

  const categories = ['Todos', 'Jogos', 'Aplicativos', 'Trabalho', 'Outros'];

  // Registered set for quick lookup
  const registeredPkgSet = useMemo(() => {
    return new Set(apps.map((a) => a.packageName));
  }, [apps]);

  // Filtered and sorted lists
  const filteredApps = useMemo(() => {
    const list = activeTab === 'registered' ? apps : installedDeviceApps;

    return list
      .filter((app) => {
        const matchesSearch =
          app.appName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.packageName.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory =
          selectedCategory === 'Todos' || app.category === selectedCategory;
        return matchesSearch && matchesCategory;
      })
      .sort((a, b) => {
        if (sortOrder === 'asc') return a.appName.localeCompare(b.appName);
        if (sortOrder === 'desc') return b.appName.localeCompare(a.appName);
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      });
  }, [activeTab, apps, installedDeviceApps, searchQuery, selectedCategory, sortOrder]);

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;
    const newApp = createCustomApp(
      customName,
      customPkg.trim() || `com.game.${customName.toLowerCase().replace(/\s+/g, '')}`,
      customCategory
    );
    setShowAddCustomModal(false);
    setCustomName('');
    setCustomPkg('');
    navigate('app_detail', { appId: newApp.id });
  };

  return (
    <div className="space-y-3 pb-8">
      {/* Tab Switcher */}
      <div className={`p-1 rounded-2xl flex border ${
        settings.darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'
      }`}>
        <button
          onClick={() => setActiveTab('registered')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'registered'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Cadastrados ({apps.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('device')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'device'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Detectados no Aparelho</span>
        </button>
      </div>

      {/* Search & Add Bar */}
      <div className="flex items-center gap-2">
        <div className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-2xl border ${
          settings.darkMode
            ? 'bg-slate-900/90 border-slate-800 text-slate-100 focus-within:border-amber-500/60'
            : 'bg-white border-slate-200 text-slate-900 focus-within:border-amber-500'
        }`}>
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Pesquisar aplicativos ou package..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs focus:outline-none placeholder:text-slate-500"
          />
        </div>

        <button
          onClick={() => setShowAddCustomModal(true)}
          className="p-2.5 rounded-2xl bg-amber-500 text-slate-950 hover:bg-amber-400 active:scale-95 transition-all shadow-md shadow-amber-500/20"
          title="Adicionar aplicativo personalizado"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
        </button>
      </div>

      {/* Category Filter Pills & Sort */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
        <div className="flex items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-slate-800 text-amber-400 border border-amber-500/40 font-semibold'
                  : settings.darkMode
                  ? 'bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-slate-200'
                  : 'bg-white text-slate-600 border border-slate-200 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <button
          onClick={() =>
            setSortOrder((prev) => (prev === 'asc' ? 'desc' : prev === 'desc' ? 'recent' : 'asc'))
          }
          className={`px-2.5 py-1 rounded-xl text-xs font-medium border flex items-center gap-1 shrink-0 ${
            settings.darkMode
              ? 'bg-slate-900 border-slate-800 text-slate-400'
              : 'bg-white border-slate-200 text-slate-600'
          }`}
          title="Alternar ordenação"
        >
          <ArrowUpDown className="w-3 h-3" />
          <span className="text-[11px] uppercase font-bold">
            {sortOrder === 'asc' ? 'A-Z' : sortOrder === 'desc' ? 'Z-A' : 'Recente'}
          </span>
        </button>
      </div>

      {/* App List */}
      <div className="space-y-2.5">
        {filteredApps.length === 0 ? (
          <div className={`p-8 rounded-2xl border text-center ${
            settings.darkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <p className="text-sm text-slate-400">Nenhum aplicativo encontrado.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('Todos');
              }}
              className="mt-2 text-xs text-amber-500 font-semibold"
            >
              Limpar filtros
            </button>
          </div>
        ) : (
          filteredApps.map((app) => {
            const isRegistered = registeredPkgSet.has(app.packageName);

            return (
              <div
                key={app.id}
                className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                  settings.darkMode
                    ? 'bg-slate-900/70 border-slate-800 hover:border-slate-700 text-slate-200'
                    : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800 shadow-sm'
                }`}
              >
                <div
                  onClick={() => {
                    if (isRegistered) {
                      navigate('app_detail', { appId: app.id });
                    }
                  }}
                  className={`flex items-center gap-3 min-w-0 flex-1 ${isRegistered ? 'cursor-pointer' : ''}`}
                >
                  <div className="w-11 h-11 rounded-2xl bg-slate-800 border border-slate-700/80 overflow-hidden shrink-0 flex items-center justify-center shadow-sm">
                    {app.iconReference.startsWith('http') ? (
                      <img
                        src={app.iconReference}
                        alt={app.appName}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <span className="text-xl">🎮</span>
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-bold truncate">{app.appName}</h3>
                      {app.favorite && (
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                      )}
                    </div>
                    <p className={`text-[11px] truncate ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {app.category} • <span className="font-mono text-[10px]">{app.packageName}</span>
                    </p>
                  </div>
                </div>

                {/* Action button */}
                <div className="shrink-0 flex items-center gap-2">
                  {isRegistered ? (
                    <button
                      onClick={() => navigate('app_detail', { appId: app.id })}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500/15 border border-amber-500/30 text-amber-500 hover:bg-amber-500 hover:text-slate-950 transition-colors"
                    >
                      Abrir Carteira
                    </button>
                  ) : (
                    <button
                      onClick={() => registerAppFromDevice(app)}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors shadow-sm"
                    >
                      + Cadastrar
                    </button>
                  )}

                  {isRegistered && (
                    <button
                      onClick={() => toggleFavoriteApp(app.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 transition-colors"
                      title="Favoritar"
                    >
                      <Star
                        className={`w-4 h-4 ${app.favorite ? 'fill-amber-400 text-amber-400' : ''}`}
                      />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Adicionar App Customizado */}
      {showAddCustomModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-3xl p-5 border ${
            settings.darkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <h3 className="text-base font-bold mb-1">Cadastrar Novo Aplicativo</h3>
            <p className={`text-xs mb-4 ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Crie uma carteira virtual para qualquer jogo ou app instalado.
            </p>

            <form onSubmit={handleCreateCustom} className="space-y-3">
              <div>
                <label className="text-xs font-semibold block mb-1">Nome do Aplicativo / Jogo *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Candy Crush Saga"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs border ${
                    settings.darkMode
                      ? 'bg-slate-800 border-slate-700 text-slate-100'
                      : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">Package Name (Opcional)</label>
                <input
                  type="text"
                  placeholder="Ex: com.king.candycrushsaga"
                  value={customPkg}
                  onChange={(e) => setCustomPkg(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs border font-mono ${
                    settings.darkMode
                      ? 'bg-slate-800 border-slate-700 text-slate-100'
                      : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">Categoria</label>
                <select
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs border ${
                    settings.darkMode
                      ? 'bg-slate-800 border-slate-700 text-slate-100'
                      : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  <option value="Jogos">Jogos</option>
                  <option value="Aplicativos">Aplicativos</option>
                  <option value="Trabalho">Trabalho</option>
                  <option value="Outros">Outros</option>
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddCustomModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-sm"
                >
                  Salvar e Criar Carteira
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
