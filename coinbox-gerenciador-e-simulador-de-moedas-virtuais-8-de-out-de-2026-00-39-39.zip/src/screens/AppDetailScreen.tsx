import React, { useState } from 'react';
import {
  Plus,
  Coins,
  ArrowUpRight,
  ArrowDownLeft,
  Trash2,
  SlidersHorizontal,
  DollarSign,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';
import { CurrencyType } from '../types/coinbox';

const PRESET_CURRENCIES: { type: CurrencyType; icon: string; defaultColor: string }[] = [
  { type: 'Moedas', icon: '🪙', defaultColor: '#eab308' },
  { type: 'Gemas', icon: '💎', defaultColor: '#06b6d4' },
  { type: 'Diamantes', icon: '🔷', defaultColor: '#3b82f6' },
  { type: 'Pontos', icon: '⭐', defaultColor: '#8b5cf6' },
  { type: 'Fichas', icon: '🎲', defaultColor: '#ec4899' },
  { type: 'Vidas', icon: '❤️', defaultColor: '#ef4444' },
  { type: 'Energia', icon: '⚡', defaultColor: '#f97316' },
  { type: 'Créditos', icon: '🎫', defaultColor: '#14b8a6' },
  { type: 'Dinheiro', icon: '💵', defaultColor: '#10b981' },
];

export const AppDetailScreen: React.FC = () => {
  const {
    apps,
    wallets,
    screenParams,
    navigate,
    deleteWallet,
    deleteApp,
    createWallet,
    updateWalletRate,
    settings,
  } = useCoinBox();

  const appId = screenParams.appId;
  const currentApp = apps.find((a) => a.id === appId);

  const [showAddWalletModal, setShowAddWalletModal] = useState(false);
  const [walletName, setWalletName] = useState('Gemas');
  const [selectedCurrencyType, setSelectedCurrencyType] = useState<CurrencyType>('Gemas');
  const [currencyIcon, setCurrencyIcon] = useState('💎');
  const [initialBalance, setInitialBalance] = useState('1000');
  const [rateEstimate, setRateEstimate] = useState('0.01');

  // Rate edit modal state
  const [editingRateWalletId, setEditingRateWalletId] = useState<string | null>(null);
  const [newRateInput, setNewRateInput] = useState('');

  if (!currentApp) {
    return (
      <div className="p-8 text-center space-y-3">
        <p className="text-sm text-slate-400">Aplicativo não encontrado ou excluído.</p>
        <button
          onClick={() => navigate('apps')}
          className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
        >
          Voltar para Lista de Apps
        </button>
      </div>
    );
  }

  const appWallets = wallets.filter((w) => w.appId === currentApp.id);

  const handleCreateWalletSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const balanceNum = parseFloat(initialBalance) || 0;
    const rateNum = parseFloat(rateEstimate) || 0.01;

    createWallet(
      currentApp.id,
      walletName.trim() || selectedCurrencyType,
      selectedCurrencyType,
      currencyIcon,
      balanceNum,
      rateNum
    );

    setShowAddWalletModal(false);
    setWalletName('');
    setInitialBalance('1000');
  };

  const handleSelectPreset = (preset: typeof PRESET_CURRENCIES[0]) => {
    setSelectedCurrencyType(preset.type);
    setCurrencyIcon(preset.icon);
    setWalletName(preset.type);
  };

  const handleSaveRate = (walletId: string) => {
    const rate = parseFloat(newRateInput);
    if (!isNaN(rate) && rate >= 0) {
      updateWalletRate(walletId, rate);
    }
    setEditingRateWalletId(null);
  };

  return (
    <div className="space-y-4 pb-8">
      {/* App Header Card */}
      <div className={`p-4 rounded-3xl border transition-all ${
        settings.darkMode
          ? 'bg-slate-900/80 border-slate-800 text-slate-100'
          : 'bg-white border-slate-200 text-slate-900 shadow-sm'
      }`}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-14 h-14 rounded-2xl bg-slate-800 border border-slate-700 overflow-hidden shrink-0 flex items-center justify-center shadow-md">
              {currentApp.iconReference.startsWith('http') ? (
                <img
                  src={currentApp.iconReference}
                  alt={currentApp.appName}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span className="text-2xl">🎮</span>
              )}
            </div>

            <div className="min-w-0">
              <h2 className="text-base font-extrabold truncate">{currentApp.appName}</h2>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-ping" />
                  Carteira CoinBox ativa
                </span>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-[11px] text-slate-400 truncate">{currentApp.category}</span>
              </div>
              <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500 truncate mt-0.5">
                {currentApp.packageName}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (confirm(`Deseja remover o aplicativo "${currentApp.appName}" e todas as suas carteiras?`)) {
                deleteApp(currentApp.id);
                navigate('apps');
              }
            }}
            className="p-2 text-rose-500 hover:bg-rose-500/10 rounded-xl transition-colors"
            title="Excluir aplicativo"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Action button: + Adicionar moeda */}
        <div className="mt-4 pt-3 border-t border-slate-500/10 flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400">
            {appWallets.length} {appWallets.length === 1 ? 'moeda cadastrada' : 'moedas cadastradas'}
          </span>

          <button
            onClick={() => setShowAddWalletModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 hover:bg-amber-400 active:scale-95 transition-all shadow-sm"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>Adicionar Moeda</span>
          </button>
        </div>
      </div>

      {/* Wallets List for this App */}
      <div className="space-y-3">
        {appWallets.length === 0 ? (
          <div className={`p-8 rounded-2xl border text-center ${
            settings.darkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <Coins className="w-8 h-8 text-amber-500/50 mx-auto mb-2" />
            <p className="text-sm font-semibold">Nenhuma moeda criada ainda</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              Adicione moedas, gemas ou pontuações virtuais para acompanhar seus saldos neste aplicativo.
            </p>
            <button
              onClick={() => setShowAddWalletModal(true)}
              className="mt-4 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
            >
              + Criar Primeira Moeda
            </button>
          </div>
        ) : (
          appWallets.map((wallet) => {
            const estimatedBrl = wallet.balance * (wallet.exchangeRateToBrl || 0);

            return (
              <div
                key={wallet.id}
                className={`p-4 rounded-3xl border transition-all ${
                  settings.darkMode
                    ? 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-slate-700'
                    : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                }`}
              >
                {/* Top wallet row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{wallet.icon}</span>
                    <div>
                      <h3 className="text-sm font-bold leading-tight">{wallet.name}</h3>
                      <span className="text-[10px] text-slate-400 uppercase tracking-wide font-medium">
                        {wallet.currencyType}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingRateWalletId(wallet.id);
                        setNewRateInput(String(wallet.exchangeRateToBrl || 0.01));
                      }}
                      className="px-2 py-1 rounded-lg text-[10px] font-semibold border border-slate-700/60 hover:border-amber-500/50 text-slate-400 hover:text-amber-400 transition-colors"
                      title="Editar taxa estimada de conversão"
                    >
                      Taxa R$
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Deseja remover a carteira "${wallet.name}"?`)) {
                          deleteWallet(wallet.id);
                        }
                      }}
                      className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg transition-colors"
                      title="Excluir carteira"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Big Balance Amount */}
                <div className="my-3 py-2 px-3 rounded-2xl bg-slate-800/40 dark:bg-slate-950/40 border border-slate-700/40 flex items-baseline justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400">Saldo Atual</span>
                    <div className="text-2xl font-black font-mono tabular-nums text-amber-400">
                      {wallet.balance.toLocaleString('pt-BR')}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Valor Estimado</span>
                    <div className="text-xs font-bold font-mono text-emerald-400">
                      R$ {estimatedBrl.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>

                {/* Rate edit inline dialog */}
                {editingRateWalletId === wallet.id && (
                  <div className="mb-3 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-2">
                    <div className="text-[11px] font-medium text-amber-400">
                      1 {wallet.icon} = R$
                    </div>
                    <input
                      type="number"
                      step="0.0001"
                      value={newRateInput}
                      onChange={(e) => setNewRateInput(e.target.value)}
                      className="w-24 px-2 py-1 rounded-lg text-xs bg-slate-900 border border-amber-500/50 text-slate-100 font-mono"
                    />
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleSaveRate(wallet.id)}
                        className="px-2 py-1 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold"
                      >
                        Salvar
                      </button>
                      <button
                        onClick={() => setEditingRateWalletId(null)}
                        className="px-2 py-1 rounded-lg text-xs text-slate-400"
                      >
                        X
                      </button>
                    </div>
                  </div>
                )}

                {/* Wallet Action Buttons */}
                <div className="grid grid-cols-3 gap-2 pt-1">
                  <button
                    onClick={() => navigate('add_balance', { walletId: wallet.id, appId: currentApp.id })}
                    className="py-2 px-2 rounded-xl text-xs font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/25 flex items-center justify-center gap-1 active:scale-95 transition-all"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>+ Saldo</span>
                  </button>

                  <button
                    onClick={() => navigate('remove_balance', { walletId: wallet.id, appId: currentApp.id })}
                    className="py-2 px-2 rounded-xl text-xs font-bold bg-rose-500/15 border border-rose-500/30 text-rose-400 hover:bg-rose-500/25 flex items-center justify-center gap-1 active:scale-95 transition-all"
                  >
                    <ArrowDownLeft className="w-3.5 h-3.5" />
                    <span>- Saldo</span>
                  </button>

                  <button
                    onClick={() => navigate('simulation', { walletId: wallet.id })}
                    className="py-2 px-2 rounded-xl text-xs font-bold bg-purple-500/15 border border-purple-500/30 text-purple-400 hover:bg-purple-500/25 flex items-center justify-center gap-1 active:scale-95 transition-all"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span>Simular</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Adicionar Moeda */}
      {showAddWalletModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-3xl p-5 border ${
            settings.darkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <h3 className="text-base font-bold mb-1">Nova Moeda / Ativo Virtual</h3>
            <p className={`text-xs mb-3 ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Configure o tipo de moeda associada a {currentApp.appName}.
            </p>

            <form onSubmit={handleCreateWalletSubmit} className="space-y-3">
              {/* Presets grid */}
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  Tipo de Ativo Pré-definido
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {PRESET_CURRENCIES.map((p) => {
                    const isSelected = selectedCurrencyType === p.type;
                    return (
                      <button
                        type="button"
                        key={p.type}
                        onClick={() => handleSelectPreset(p)}
                        className={`p-1.5 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-500 text-amber-400 font-bold'
                            : 'bg-slate-800/50 border-slate-700/60 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <span className="text-base">{p.icon}</span>
                        <span className="truncate">{p.type}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">Nome do Ativo</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Diamantes Royale"
                  value={walletName}
                  onChange={(e) => setWalletName(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs border ${
                    settings.darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-300'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-semibold block mb-1">Saldo Inicial</label>
                  <input
                    type="number"
                    min="0"
                    value={initialBalance}
                    onChange={(e) => setInitialBalance(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl text-xs border font-mono ${
                      settings.darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-300'
                    }`}
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">Cotação Estimada (R$)</label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    value={rateEstimate}
                    onChange={(e) => setRateEstimate(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl text-xs border font-mono ${
                      settings.darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-300'
                    }`}
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddWalletModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-sm"
                >
                  Criar Moeda
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
