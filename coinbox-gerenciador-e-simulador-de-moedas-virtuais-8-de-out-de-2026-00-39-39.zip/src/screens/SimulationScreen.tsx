import React, { useState } from 'react';
import {
  SlidersHorizontal,
  Sparkles,
  RotateCcw,
  CheckCheck,
  AlertCircle,
  TrendingUp,
  Layers,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

export const SimulationScreen: React.FC = () => {
  const {
    wallets,
    apps,
    screenParams,
    simulatedBalances,
    setSimulatedAmount,
    commitSimulation,
    discardSimulation,
    settings,
    navigate,
  } = useCoinBox();

  const initialWalletId = screenParams.walletId || wallets[0]?.id;
  const [selectedWalletId, setSelectedWalletId] = useState<string>(initialWalletId || '');

  const selectedWallet = wallets.find((w) => w.id === selectedWalletId);
  const targetApp = selectedWallet ? apps.find((a) => a.id === selectedWallet.appId) : null;

  const currentRealBalance = selectedWallet ? selectedWallet.balance : 0;
  const activeSimulatedBalance =
    selectedWallet && simulatedBalances[selectedWallet.id] !== undefined
      ? simulatedBalances[selectedWallet.id]
      : currentRealBalance;

  // Local draft slider / delta state
  const delta = activeSimulatedBalance - currentRealBalance;

  const applyDelta = (d: number) => {
    if (!selectedWallet) return;
    const nextVal = Math.max(0, activeSimulatedBalance + d);
    setSimulatedAmount(selectedWallet.id, nextVal);
  };

  const applyMultiplier = (mult: number) => {
    if (!selectedWallet) return;
    const nextVal = Math.round(currentRealBalance * mult);
    setSimulatedAmount(selectedWallet.id, nextVal);
  };

  const resetToReal = () => {
    if (!selectedWallet) return;
    discardSimulation(selectedWallet.id);
  };

  return (
    <div className="space-y-4 pb-8 max-w-lg mx-auto">
      {/* Simulation Banner */}
      <div className={`p-4 rounded-3xl border transition-all ${
        settings.darkMode
          ? 'bg-gradient-to-br from-slate-900 via-purple-950/30 to-slate-900 border-purple-500/40 text-slate-100 shadow-lg shadow-purple-950/20'
          : 'bg-gradient-to-br from-purple-50 via-white to-amber-50 border-purple-200 text-slate-900 shadow-sm'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <SlidersHorizontal className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-base font-extrabold">Modo Simulação Sandbox</h2>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30 uppercase">
                Teste Seguro
              </span>
            </div>
            <p className={`text-xs ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Experimente metas e testes sem alterar o saldo real até você confirmar.
            </p>
          </div>
        </div>
      </div>

      {/* Wallet Selector */}
      <div className={`p-4 rounded-2xl border ${
        settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <label className="text-xs font-bold text-slate-400 uppercase tracking-wide block mb-2">
          Carteira em Teste
        </label>
        <select
          value={selectedWalletId}
          onChange={(e) => setSelectedWalletId(e.target.value)}
          className={`w-full p-3 rounded-xl text-sm font-semibold border ${
            settings.darkMode
              ? 'bg-slate-800 border-slate-700 text-slate-100'
              : 'bg-slate-50 border-slate-300 text-slate-900'
          }`}
        >
          {wallets.map((w) => {
            const a = apps.find((app) => app.id === w.appId);
            const isSimulated = simulatedBalances[w.id] !== undefined;
            return (
              <option key={w.id} value={w.id}>
                {w.icon} {w.name} ({a?.appName || 'App'}) {isSimulated ? '• [SIMULAÇÃO ATIVA]' : ''}
              </option>
            );
          })}
        </select>
      </div>

      {selectedWallet && (
        <>
          {/* Compare Card: Real vs Simulado */}
          <div className={`p-4 rounded-3xl border ${
            settings.darkMode
              ? 'bg-slate-900/90 border-slate-800 text-slate-100'
              : 'bg-white border-slate-200 text-slate-900 shadow-sm'
          }`}>
            <div className="grid grid-cols-2 gap-3 pb-3 border-b border-slate-500/15">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Saldo Real do CoinBox
                </span>
                <div className="text-lg font-black font-mono tabular-nums text-slate-300 mt-0.5">
                  {currentRealBalance.toLocaleString('pt-BR')} {selectedWallet.icon}
                </div>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-purple-400 block">
                  Resultado Simulado
                </span>
                <div className="text-xl font-black font-mono tabular-nums text-purple-400 mt-0.5">
                  {activeSimulatedBalance.toLocaleString('pt-BR')} {selectedWallet.icon}
                </div>
              </div>
            </div>

            {/* Delta summary */}
            <div className="pt-3 flex items-center justify-between text-xs">
              <span className="text-slate-400">Variação da simulação:</span>
              <span
                className={`font-black font-mono tabular-nums px-2 py-0.5 rounded-lg ${
                  delta > 0
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : delta < 0
                    ? 'bg-rose-500/15 text-rose-400'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {delta > 0 ? `+${delta.toLocaleString('pt-BR')}` : delta.toLocaleString('pt-BR')} {selectedWallet.icon}
              </span>
            </div>
          </div>

          {/* Quick Simulation controls */}
          <div className={`p-4 rounded-2xl border space-y-3 ${
            settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wide">
              Adicionar ou Remover em Simulação
            </h3>

            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={() => applyDelta(1000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 active:scale-95 transition-all"
              >
                +1.000
              </button>
              <button
                onClick={() => applyDelta(10000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 active:scale-95 transition-all"
              >
                +10.000
              </button>
              <button
                onClick={() => applyDelta(50000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 active:scale-95 transition-all"
              >
                +50.000
              </button>
              <button
                onClick={() => applyDelta(100000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 active:scale-95 transition-all"
              >
                +100.000
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                onClick={() => applyDelta(-1000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-rose-400 border border-slate-700 active:scale-95 transition-all"
              >
                -1.000
              </button>
              <button
                onClick={() => applyDelta(-5000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-rose-400 border border-slate-700 active:scale-95 transition-all"
              >
                -5.000
              </button>
              <button
                onClick={() => applyDelta(-25000)}
                className="py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-rose-400 border border-slate-700 active:scale-95 transition-all"
              >
                -25.000
              </button>
            </div>

            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide pt-2">
              Multiplicadores de Evento Especial
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => applyMultiplier(2)}
                className="py-2 rounded-xl text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 hover:bg-purple-500/30 active:scale-95 transition-all"
              >
                2x Dobro
              </button>
              <button
                onClick={() => applyMultiplier(5)}
                className="py-2 rounded-xl text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 hover:bg-purple-500/30 active:scale-95 transition-all"
              >
                5x Evento
              </button>
              <button
                onClick={() => applyMultiplier(10)}
                className="py-2 rounded-xl text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 hover:bg-purple-500/30 active:scale-95 transition-all"
              >
                10x Megabônus
              </button>
            </div>

            {/* Custom Input */}
            <div className="pt-2">
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                Definir Saldo Simulado Específico
              </label>
              <input
                type="number"
                min="0"
                value={activeSimulatedBalance}
                onChange={(e) => {
                  const val = Math.max(0, parseFloat(e.target.value) || 0);
                  setSimulatedAmount(selectedWallet.id, val);
                }}
                className={`w-full px-3 py-2 rounded-xl text-sm font-mono font-bold border ${
                  settings.darkMode
                    ? 'bg-slate-950 border-slate-700 text-purple-400'
                    : 'bg-slate-50 border-slate-300 text-purple-600'
                }`}
              />
            </div>
          </div>

          {/* Action Buttons: "Salvar simulação" & "Descartar" as specified in Prompt 13 */}
          <div className="pt-2 flex items-center gap-3">
            <button
              onClick={resetToReal}
              className="flex-1 py-3 px-4 rounded-2xl border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Descartar</span>
            </button>

            <button
              onClick={() => {
                commitSimulation(selectedWallet.id);
                navigate('app_detail', { appId: selectedWallet.appId });
              }}
              className="flex-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-500 to-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 hover:brightness-105 shadow-lg shadow-purple-500/20 active:scale-[0.98] transition-all"
            >
              <CheckCheck className="w-4 h-4 stroke-[2.5]" />
              <span>Salvar Simulação no Saldo Real</span>
            </button>
          </div>
        </>
      )}
    </div>
  );
};
