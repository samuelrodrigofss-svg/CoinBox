import React from 'react';
import { ShieldCheck, Sparkles, Layers, Sliders, ArrowRight } from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

export const OnboardingScreen: React.FC = () => {
  const { updateSettings, navigate, settings } = useCoinBox();

  const handleStart = () => {
    updateSettings({ hasCompletedOnboarding: true });
    navigate('home');
  };

  const features = [
    {
      icon: Layers,
      title: 'Carteiras por Jogo & Aplicativo',
      desc: 'Associe saldos de moedas, gemas, diamantes e vidas aos seus jogos prediletos.',
    },
    {
      icon: Sliders,
      title: 'Modo Simulação Sandbox',
      desc: 'Teste ganhos e gastos virtuais sem afetar seus saldos principais salvos.',
    },
    {
      icon: ShieldCheck,
      title: '100% Seguro & Independente',
      desc: 'Cofre offline com banco Room local. Não acessa arquivos internos nem altera dados de terceiros.',
    },
  ];

  return (
    <div className={`min-h-full flex flex-col justify-between p-6 transition-colors ${
      settings.darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Top Header */}
      <div className="pt-6 flex flex-col items-center text-center">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-200 p-0.5 shadow-xl shadow-amber-500/20 mb-5 flex items-center justify-center">
          <div className="w-full h-full bg-slate-900 rounded-[22px] flex items-center justify-center text-3xl">
            🪙
          </div>
        </div>

        <span className="text-xs uppercase tracking-wider font-bold text-amber-500 mb-1">
          Android Material 3 Architecture
        </span>
        <h1 className="text-2xl font-extrabold tracking-tight">
          Bem-vindo ao CoinBox
        </h1>
        <p className={`text-sm mt-2 max-w-xs leading-relaxed ${settings.darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
          Crie e gerencie carteiras digitais associadas aos seus aplicativos e jogos com simulação avançada de saldo.
        </p>
      </div>

      {/* Feature cards */}
      <div className="my-8 space-y-3">
        {features.map((f, i) => {
          const Icon = f.icon;
          return (
            <div
              key={i}
              className={`p-3.5 rounded-2xl border transition-all flex items-start gap-3.5 ${
                settings.darkMode
                  ? 'bg-slate-900/60 border-slate-800 text-slate-200'
                  : 'bg-white border-slate-200/80 text-slate-800 shadow-sm'
              }`}
            >
              <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h2 className="text-sm font-semibold">{f.title}</h2>
                <p className={`text-xs mt-0.5 leading-relaxed ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {f.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer CTA */}
      <div className="pb-4 space-y-3">
        <button
          onClick={handleStart}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 hover:brightness-105 active:scale-[0.98] transition-all"
        >
          <span>Começar Agora</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <p className={`text-[11px] text-center ${settings.darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
          Privacidade preservada • Room Database Local • Sem coleta de dados
        </p>
      </div>
    </div>
  );
};
