import React from 'react';
import {
  Layers,
  PlusCircle,
  Clock,
  Settings,
  Sparkles,
  TrendingUp,
  Star,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronRight,
  SlidersHorizontal,
  Wallet as WalletIcon,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';
import { AdMobBannerView } from '../components/AdMobBannerView';

export const HomeScreen: React.FC = () => {
  const {
    apps,
    wallets,
    transactions,
    settings,
    navigate,
    toggleFavoriteApp,
    simulatedBalances,
  } = useCoinBox();

  // Aggregate calculations
  const totalAppsCount = apps.length;

  // Calculate estimated total virtual value in BRL/Currency
  const estimatedTotalBrl = wallets.reduce((acc, w) => {
    const rate = w.exchangeRateToBrl || 0;
    return acc + w.balance * rate;
  }, 0);

  // Total quantity of all currency units across all wallets
  const totalUnitsCount = wallets.reduce((acc, w) => acc + w.balance, 0);

  // Favorite apps list
  const favoriteApps = apps.filter((a) => a.favorite);
  const displayApps = favoriteApps.length > 0 ? favoriteApps : apps.slice(0, 4);

  // Recent 4 transactions
  const recentTransactions = transactions.slice(0, 4);

  // Check if simulation mode has active overrides
  const hasActiveSimulations = Object.keys(simulatedBalances).length > 0;

  return (
    <div className="space-y-4 pb-6">
      {/* Brand & Total Balance Hero Card */}
      <div className={`p-4 rounded-3xl border transition-all relative overflow-hidden ${
        settings.darkMode
          ? 'bg-gradient-to-br from-slate-900 via-slate-800 to-amber-950/30 border-slate-700/80 text-white shadow-xl shadow-black/40'
          : 'bg-gradient-to-br from-white via-amber-50/50 to-orange-50/40 border-amber-200/80 text-slate-900 shadow-md shadow-amber-900/5'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-xl shadow-inner">
              🪙
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-extrabold tracking-tight">CoinBox</span>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-500 border border-amber-500/30">
                  VIRTUAL WALLET
                </span>
              </div>
              <p className={`text-[11px] ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {totalAppsCount} {totalAppsCount === 1 ? 'aplicativo cadastrado' : 'aplicativos cadastrados'}
              </p>
            </div>
          </div>

          <button
            onClick={() => navigate('simulation')}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all active:scale-95 ${
              hasActiveSimulations
                ? 'bg-purple-500/20 border-purple-500 text-purple-400 animate-pulse'
                : settings.darkMode
                ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
                : 'bg-amber-100/70 border-amber-300 text-amber-900 hover:bg-amber-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="text-[11px]">Simulador</span>
          </button>
        </div>

        {/* Big Balance Number */}
        <div className="my-3">
          <span className={`text-[11px] font-medium tracking-wide uppercase ${
            settings.darkMode ? 'text-slate-400' : 'text-slate-500'
          }`}>
            Saldo Total em Carteira (Estimado)
          </span>
          <div className="flex items-baseline gap-2 mt-0.5">
            <span className="text-2xl font-black tracking-tight tabular-nums font-mono">
              {settings.currencySymbol} {estimatedTotalBrl.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className={`text-xs ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              ({totalUnitsCount.toLocaleString('pt-BR')} unidades virtuais)
            </span>
          </div>
          <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 italic">
            * Cotação de referência definida pelo usuário no CoinBox.
          </p>
        </div>

        {/* 4 Main Action Buttons requested in spec */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-500/10 dark:border-slate-800">
          <button
            onClick={() => navigate('apps')}
            className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition-all active:scale-95 ${
              settings.darkMode
                ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800 shadow-sm'
            }`}
          >
            <Layers className="w-4 h-4 text-blue-500 mb-1" />
            <span className="text-[11px] font-semibold text-center leading-tight">Meus Apps</span>
          </button>

          <button
            onClick={() => navigate('apps', { tab: 'available' })}
            className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition-all active:scale-95 ${
              settings.darkMode
                ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800 shadow-sm'
            }`}
          >
            <PlusCircle className="w-4 h-4 text-amber-500 mb-1" />
            <span className="text-[11px] font-semibold text-center leading-tight">+ Adicionar</span>
          </button>

          <button
            onClick={() => navigate('history')}
            className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition-all active:scale-95 ${
              settings.darkMode
                ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800 shadow-sm'
            }`}
          >
            <Clock className="w-4 h-4 text-emerald-500 mb-1" />
            <span className="text-[11px] font-semibold text-center leading-tight">Histórico</span>
          </button>

          <button
            onClick={() => navigate('settings')}
            className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition-all active:scale-95 ${
              settings.darkMode
                ? 'bg-slate-800/60 border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800 shadow-sm'
            }`}
          >
            <Settings className="w-4 h-4 text-purple-500 mb-1" />
            <span className="text-[11px] font-semibold text-center leading-tight">Ajustes</span>
          </button>
        </div>
      </div>

      {/* AdMob Banner Slot */}
      <AdMobBannerView placement="Home Feed" />

      {/* Meus Aplicativos Section */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center gap-1.5">
            <h2 className="text-sm font-bold tracking-tight">Meus Aplicativos</h2>
            <span className="text-xs text-slate-400">({apps.length})</span>
          </div>
          <button
            onClick={() => navigate('apps')}
            className="text-xs font-semibold text-amber-500 hover:text-amber-400 flex items-center gap-0.5"
          >
            <span>Ver todos</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {apps.length === 0 ? (
          <div className={`p-6 rounded-2xl border text-center ${
            settings.darkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <p className="text-sm text-slate-400">Nenhum aplicativo cadastrado ainda.</p>
            <button
              onClick={() => navigate('apps', { tab: 'available' })}
              className="mt-3 px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
            >
              Adicionar Primeiro App
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {displayApps.map((app) => {
              const appWallets = wallets.filter((w) => w.appId === app.id);
              return (
                <div
                  key={app.id}
                  onClick={() => navigate('app_detail', { appId: app.id })}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer active:scale-[0.99] group ${
                    settings.darkMode
                      ? 'bg-slate-900/70 border-slate-800 hover:border-slate-700 text-slate-200'
                      : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-11 h-11 rounded-2xl bg-slate-800 border border-slate-700/80 overflow-hidden shrink-0 flex items-center justify-center shadow-sm">
                        {app.iconReference.startsWith('http') ? (
                          <img
                            src={app.iconReference}
                            alt={app.appName}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <span className="text-xl">🎮</span>
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-sm font-bold truncate group-hover:text-amber-500 transition-colors">
                            {app.appName}
                          </h3>
                          {app.favorite && (
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                          )}
                        </div>
                        <p className={`text-[11px] truncate ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {app.category} • {app.packageName}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavoriteApp(app.id);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 transition-colors"
                      title="Favoritar aplicativo"
                    >
                      <Star
                        className={`w-4 h-4 ${app.favorite ? 'fill-amber-400 text-amber-400' : ''}`}
                      />
                    </button>
                  </div>

                  {/* Wallet Currencies Pills Row */}
                  <div className="mt-3 pt-2.5 border-t border-slate-500/10 flex flex-wrap gap-2">
                    {appWallets.length === 0 ? (
                      <span className="text-xs text-slate-400 italic">Nenhuma carteira configurada</span>
                    ) : (
                      appWallets.map((wallet) => (
                        <div
                          key={wallet.id}
                          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-medium border ${
                            settings.darkMode
                              ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                              : 'bg-slate-100/90 border-slate-200 text-slate-800'
                          }`}
                        >
                          <span className="text-sm">{wallet.icon}</span>
                          <span className="tabular-nums font-mono font-bold">
                            {wallet.balance.toLocaleString('pt-BR')}
                          </span>
                          <span className="text-[11px] opacity-75">{wallet.name}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent Ledger History */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <h2 className="text-sm font-bold tracking-tight">Últimas Operações</h2>
          <button
            onClick={() => navigate('history')}
            className="text-xs font-semibold text-amber-500 hover:text-amber-400 flex items-center gap-0.5"
          >
            <span>Ver tudo</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentTransactions.length === 0 ? (
          <div className={`p-4 rounded-2xl border text-center text-xs text-slate-400 ${
            settings.darkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            Nenhuma operação recente registrada.
          </div>
        ) : (
          <div className="space-y-2">
            {recentTransactions.map((tx) => {
              const isCredit = tx.type === 'CREDIT' || tx.type === 'SIMULATION_APPLY';
              return (
                <div
                  key={tx.id}
                  className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                    settings.darkMode
                      ? 'bg-slate-900/60 border-slate-800 text-slate-200'
                      : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        isCredit
                          ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-500 border border-rose-500/30'
                      }`}
                    >
                      {isCredit ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownLeft className="w-4 h-4" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold truncate">{tx.appName}</span>
                        <span className="text-[10px] opacity-60">· {tx.walletName}</span>
                      </div>
                      <p className={`text-[10px] truncate ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        {tx.description}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div
                      className={`text-xs font-black tabular-nums font-mono ${
                        isCredit ? 'text-emerald-500' : 'text-rose-500'
                      }`}
                    >
                      {isCredit ? '+' : '-'}
                      {tx.amount.toLocaleString('pt-BR')} {tx.currencyIcon}
                    </div>
                    <div className={`text-[10px] ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      Saldo: {tx.newBalance.toLocaleString('pt-BR')}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
