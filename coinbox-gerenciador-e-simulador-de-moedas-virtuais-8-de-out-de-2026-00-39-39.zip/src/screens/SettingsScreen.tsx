import React, { useState, useRef } from 'react';
import {
  Moon,
  Sun,
  Bell,
  Volume2,
  VolumeX,
  ShieldCheck,
  Sparkles,
  Download,
  Upload,
  RefreshCw,
  SlidersHorizontal,
  DollarSign,
  Tag,
  Plus,
  Info,
  Check,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

export const SettingsScreen: React.FC = () => {
  const {
    settings,
    updateSettings,
    togglePremium,
    categories,
    addCategory,
    generateExport,
    importBackupJson,
    resetDatabase,
    navigate,
  } = useCoinBox();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newCatName, setNewCatName] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('🎮');
  const [showCatModal, setShowCatModal] = useState(false);

  const handleExportJson = () => {
    const jsonStr = generateExport('json');
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `coinbox_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const res = importBackupJson(content);
        if (!res.success) {
          alert(res.error || 'Erro ao importar backup');
        }
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    addCategory(newCatName.trim(), newCatIcon || '🏷️');
    setNewCatName('');
    setShowCatModal(false);
  };

  return (
    <div className="space-y-4 pb-10 max-w-lg mx-auto">
      {/* CoinBox Premium Banner */}
      <div className={`p-4 rounded-3xl border transition-all relative overflow-hidden ${
        settings.isPremium
          ? 'bg-gradient-to-r from-amber-500/20 via-amber-400/20 to-yellow-500/10 border-amber-500/40'
          : 'bg-gradient-to-r from-slate-900 via-slate-800 to-purple-950/40 border-slate-700'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl">
              ⭐
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-extrabold">CoinBox Premium</h2>
                {settings.isPremium && (
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 uppercase">
                    ATIVO
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                {settings.isPremium
                  ? 'Todos os recursos Pro desbloqueados sem anúncios.'
                  : 'Carteiras ilimitadas, sem anúncios e backup avançado.'}
              </p>
            </div>
          </div>

          <button
            onClick={togglePremium}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              settings.isPremium
                ? 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                : 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-md shadow-amber-500/20'
            }`}
          >
            {settings.isPremium ? 'Desativar PRO' : 'Ativar PRO'}
          </button>
        </div>
      </div>

      {/* General Preferences */}
      <div className={`p-4 rounded-3xl border space-y-3.5 ${
        settings.darkMode ? 'bg-slate-900/70 border-slate-800 text-slate-200' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
      }`}>
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400">
          Preferências Gerais
        </h3>

        {/* Dark Mode toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {settings.darkMode ? (
              <Moon className="w-4 h-4 text-purple-400" />
            ) : (
              <Sun className="w-4 h-4 text-amber-500" />
            )}
            <div>
              <div className="text-xs font-semibold">Tema Escuro (Dark Mode)</div>
              <div className="text-[10px] text-slate-400">Interface noturna moderna Material 3</div>
            </div>
          </div>
          <button
            onClick={() => updateSettings({ darkMode: !settings.darkMode })}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              settings.darkMode ? 'bg-amber-500' : 'bg-slate-300'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                settings.darkMode ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Negative Balance toggle (Prompt 8 & 16) */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-500/10">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-xs font-semibold">Permitir Saldo Negativo</div>
              <div className="text-[10px] text-slate-400">Permite débitos maiores que o saldo em carteira</div>
            </div>
          </div>
          <button
            onClick={() => updateSettings({ allowNegativeBalance: !settings.allowNegativeBalance })}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              settings.allowNegativeBalance ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                settings.allowNegativeBalance ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Notifications toggle (Prompt 19) */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-500/10">
          <div className="flex items-center gap-2.5">
            <Bell className="w-4 h-4 text-blue-400" />
            <div>
              <div className="text-xs font-semibold">Notificações de Saldo</div>
              <div className="text-[10px] text-slate-400">Alertas rápidos ao atualizar saldos</div>
            </div>
          </div>
          <button
            onClick={() => updateSettings({ notifications: !settings.notifications })}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              settings.notifications ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                settings.notifications ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Sound Effects toggle */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-500/10">
          <div className="flex items-center gap-2.5">
            {settings.soundEffects ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-500" />
            )}
            <div>
              <div className="text-xs font-semibold">Efeitos Sonoros e Hápticos</div>
              <div className="text-[10px] text-slate-400">Feedback tátil nas operações de moedas</div>
            </div>
          </div>
          <button
            onClick={() => updateSettings({ soundEffects: !settings.soundEffects })}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              settings.soundEffects ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                settings.soundEffects ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Currency Symbol */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-500/10">
          <div className="flex items-center gap-2.5">
            <DollarSign className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-xs font-semibold">Moeda de Referência</div>
              <div className="text-[10px] text-slate-400">Símbolo para conversão estimada</div>
            </div>
          </div>
          <select
            value={settings.currencySymbol}
            onChange={(e) => updateSettings({ currencySymbol: e.target.value })}
            className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-800 border border-slate-700 text-slate-100"
          >
            <option value="R$">Real (R$)</option>
            <option value="$">Dólar ($)</option>
            <option value="€">Euro (€)</option>
          </select>
        </div>
      </div>

      {/* Categories Management (Prompt 12) */}
      <div className={`p-4 rounded-3xl border space-y-3 ${
        settings.darkMode ? 'bg-slate-900/70 border-slate-800 text-slate-200' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
      }`}>
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5" />
            <span>Categorias de Aplicativos</span>
          </h3>
          <button
            onClick={() => setShowCatModal(true)}
            className="text-xs text-amber-500 font-bold hover:underline flex items-center gap-1"
          >
            <Plus className="w-3 h-3" />
            <span>Nova Categoria</span>
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <div
              key={c.id}
              className="px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/80 border border-slate-700/60 flex items-center gap-1.5"
            >
              <span>{c.icon}</span>
              <span>{c.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Backup & Restore (Prompt 20) */}
      <div className={`p-4 rounded-3xl border space-y-3 ${
        settings.darkMode ? 'bg-slate-900/70 border-slate-800 text-slate-200' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
      }`}>
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400">
          Backup e Restauração (JSON)
        </h3>
        <p className="text-[11px] text-slate-400">
          Exporte e importe seus dados de moedas e histórico do CoinBox de maneira segura e independente.
        </p>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={handleExportJson}
            className="py-2.5 px-3 rounded-2xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Exportar Backup</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="py-2.5 px-3 rounded-2xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Restaurar JSON</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".json,application/json"
            className="hidden"
          />
        </div>
      </div>

      {/* Dangerous Zone / Reset */}
      <div className={`p-4 rounded-3xl border ${
        settings.darkMode ? 'bg-rose-950/20 border-rose-900/40 text-slate-200' : 'bg-rose-50 border-rose-200 text-slate-800'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-rose-400">Restaurar Banco de Dados</div>
            <div className="text-[10px] text-slate-400">Retorna aos aplicativos e dados iniciais de demonstração</div>
          </div>
          <button
            onClick={() => {
              if (confirm('Tem certeza que deseja restaurar as configurações e dados de fábrica?')) {
                resetDatabase();
              }
            }}
            className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/40 text-xs font-bold transition-colors"
          >
            Restaurar
          </button>
        </div>
      </div>

      {/* Category Creation Modal */}
      {showCatModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-3xl p-5 border ${
            settings.darkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <h3 className="text-base font-bold mb-2">Criar Nova Categoria</h3>
            <form onSubmit={handleCreateCategory} className="space-y-3">
              <div>
                <label className="text-xs font-semibold block mb-1">Nome da Categoria</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: RPG & Fantasia"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-800 border border-slate-700 text-slate-100"
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">Ícone / Emoji</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={3}
                    value={newCatIcon}
                    onChange={(e) => setNewCatIcon(e.target.value)}
                    className="w-16 px-3 py-2 rounded-xl text-center text-lg bg-slate-800 border border-slate-700 text-slate-100"
                  />
                  <div className="flex gap-1">
                    {['🎮', '📱', '🏆', '💎', '🎯', '🔥', '⚔️'].map((em) => (
                      <button
                        type="button"
                        key={em}
                        onClick={() => setNewCatIcon(em)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm"
                      >
                        {em}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCatModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400"
                >
                  Criar Categoria
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
