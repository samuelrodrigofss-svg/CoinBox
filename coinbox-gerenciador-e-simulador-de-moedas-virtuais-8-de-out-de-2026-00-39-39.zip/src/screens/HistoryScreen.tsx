import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Trash2,
  Download,
  Calendar,
  ArrowUpRight,
  ArrowDownLeft,
  Coins,
  FileSpreadsheet,
  FileCode,
  FileText,
  SlidersHorizontal,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';
import { AdMobBannerView } from '../components/AdMobBannerView';

export const HistoryScreen: React.FC = () => {
  const {
    transactions,
    apps,
    wallets,
    deleteTransaction,
    clearTransactions,
    generateExport,
    settings,
  } = useCoinBox();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAppId, setSelectedAppId] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<'today' | '7days' | '30days' | 'all'>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'CREDIT' | 'DEBIT'>('all');
  const [showExportModal, setShowExportModal] = useState(false);

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    const now = new Date().getTime();
    const oneDay = 24 * 60 * 60 * 1000;

    return transactions.filter((tx) => {
      // Search
      const matchesSearch =
        tx.appName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.walletName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.description.toLowerCase().includes(searchQuery.toLowerCase());

      // App
      const matchesApp = selectedAppId === 'all' || tx.appId === selectedAppId;

      // Type
      const matchesType =
        selectedType === 'all' ||
        (selectedType === 'CREDIT' && (tx.type === 'CREDIT' || tx.type === 'SIMULATION_APPLY')) ||
        (selectedType === 'DEBIT' && tx.type === 'DEBIT');

      // Period
      const txTime = new Date(tx.createdAt).getTime();
      let matchesPeriod = true;
      if (selectedPeriod === 'today') {
        matchesPeriod = now - txTime <= oneDay;
      } else if (selectedPeriod === '7days') {
        matchesPeriod = now - txTime <= 7 * oneDay;
      } else if (selectedPeriod === '30days') {
        matchesPeriod = now - txTime <= 30 * oneDay;
      }

      return matchesSearch && matchesApp && matchesType && matchesPeriod;
    });
  }, [transactions, searchQuery, selectedAppId, selectedPeriod, selectedType]);

  const handleDownloadFile = (format: 'json' | 'csv' | 'txt') => {
    const content = generateExport(format);
    const mime =
      format === 'json'
        ? 'application/json'
        : format === 'csv'
        ? 'text/csv'
        : 'text/plain';
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `coinbox_historico_${new Date().toISOString().slice(0, 10)}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportModal(false);
  };

  return (
    <div className="space-y-3 pb-8">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between gap-2">
        <div className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-2xl border ${
          settings.darkMode
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}>
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Pesquisar histórico..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs focus:outline-none placeholder:text-slate-500"
          />
        </div>

        <button
          onClick={() => setShowExportModal(true)}
          className="p-2.5 rounded-2xl border border-slate-700 bg-slate-800 text-slate-200 hover:text-white hover:border-amber-500 transition-colors"
          title="Exportar histórico (CSV, JSON, TXT)"
        >
          <Download className="w-4 h-4" />
        </button>

        {transactions.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Tem certeza que deseja limpar todo o histórico de operações?')) {
                clearTransactions();
              }
            }}
            className="p-2.5 rounded-2xl border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 transition-colors"
            title="Limpar todo o histórico"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Filter Row: App & Period */}
      <div className="grid grid-cols-2 gap-2">
        <select
          value={selectedAppId}
          onChange={(e) => setSelectedAppId(e.target.value)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold border truncate ${
            settings.darkMode
              ? 'bg-slate-900 border-slate-800 text-slate-200'
              : 'bg-white border-slate-200 text-slate-800'
          }`}
        >
          <option value="all">Todos os Aplicativos</option>
          {apps.map((a) => (
            <option key={a.id} value={a.id}>
              {a.appName}
            </option>
          ))}
        </select>

        <select
          value={selectedPeriod}
          onChange={(e) => setSelectedPeriod(e.target.value as any)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
            settings.darkMode
              ? 'bg-slate-900 border-slate-800 text-slate-200'
              : 'bg-white border-slate-200 text-slate-800'
          }`}
        >
          <option value="all">Todo o Período</option>
          <option value="today">Hoje (24h)</option>
          <option value="7days">Últimos 7 dias</option>
          <option value="30days">Últimos 30 dias</option>
        </select>
      </div>

      {/* AdMob Banner for History placement */}
      <AdMobBannerView placement="Histórico de Transações" />

      {/* Ledger List */}
      <div className="space-y-2.5">
        {filteredTransactions.length === 0 ? (
          <div className={`p-8 rounded-2xl border text-center ${
            settings.darkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <p className="text-sm text-slate-400">Nenhum registro encontrado no histórico.</p>
            {(searchQuery || selectedAppId !== 'all' || selectedPeriod !== 'all') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedAppId('all');
                  setSelectedPeriod('all');
                }}
                className="mt-2 text-xs text-amber-500 font-semibold"
              >
                Limpar filtros de busca
              </button>
            )}
          </div>
        ) : (
          filteredTransactions.map((tx) => {
            const isCredit = tx.type === 'CREDIT' || tx.type === 'SIMULATION_APPLY';
            const dateObj = new Date(tx.createdAt);
            const dateFormatted = `${dateObj.toLocaleDateString('pt-BR')} — ${dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;

            return (
              <div
                key={tx.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  settings.darkMode
                    ? 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-slate-700'
                    : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                }`}
              >
                {/* Header line: Date & App */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-500/10 pb-2 mb-2.5">
                  <span className="font-mono">{dateFormatted}</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-300 truncate max-w-[140px]">{tx.appName}</span>
                    <button
                      onClick={() => deleteTransaction(tx.id)}
                      className="text-slate-500 hover:text-rose-400 p-0.5 rounded transition-colors"
                      title="Excluir este registro"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Main body line */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        isCredit
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {isCredit ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownLeft className="w-4 h-4" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold truncate">
                          {tx.walletName}
                        </span>
                        <span className="text-base">{tx.currencyIcon}</span>
                      </div>
                      <p className={`text-[11px] truncate ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        {tx.description}
                      </p>
                    </div>
                  </div>

                  {/* Amounts */}
                  <div className="text-right shrink-0 font-mono">
                    <div
                      className={`text-sm font-black tabular-nums ${
                        isCredit ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isCredit ? '+' : '-'}
                      {tx.amount.toLocaleString('pt-BR')}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Saldo: <span className="font-bold">{tx.newBalance.toLocaleString('pt-BR')}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-3xl p-5 border ${
            settings.darkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <h3 className="text-base font-bold mb-1">Exportar Histórico de Operações</h3>
            <p className={`text-xs mb-4 ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Escolha o formato desejado para salvar ou compartilhar seus dados do CoinBox.
            </p>

            <div className="space-y-2">
              <button
                onClick={() => handleDownloadFile('csv')}
                className="w-full p-3 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 flex items-center gap-3 text-xs font-bold transition-all"
              >
                <FileSpreadsheet className="w-5 h-5 shrink-0" />
                <div className="text-left">
                  <div>Exportar como CSV (Planilhas Excel/Google)</div>
                  <div className="text-[10px] font-normal text-slate-400">Tabela estruturada com colunas de saldo</div>
                </div>
              </button>

              <button
                onClick={() => handleDownloadFile('json')}
                className="w-full p-3 rounded-2xl border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 flex items-center gap-3 text-xs font-bold transition-all"
              >
                <FileCode className="w-5 h-5 shrink-0" />
                <div className="text-left">
                  <div>Exportar como JSON (Backup Completo)</div>
                  <div className="text-[10px] font-normal text-slate-400">Estrutura de dados para restauração rápida</div>
                </div>
              </button>

              <button
                onClick={() => handleDownloadFile('txt')}
                className="w-full p-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 flex items-center gap-3 text-xs font-bold transition-all"
              >
                <FileText className="w-5 h-5 shrink-0" />
                <div className="text-left">
                  <div>Exportar como TXT (Relatório em Texto)</div>
                  <div className="text-[10px] font-normal text-slate-400">Relatório legível para impressão ou bloco de notas</div>
                </div>
              </button>
            </div>

            <div className="mt-4 pt-2 text-right">
              <button
                onClick={() => setShowExportModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
