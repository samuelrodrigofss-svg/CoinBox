import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Layers,
  Coins,
  Crown,
  PieChart,
  ArrowUpRight,
  ArrowDownLeft,
  Flame,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';
import { AdMobBannerView } from '../components/AdMobBannerView';

export const DashboardScreen: React.FC = () => {
  const { apps, wallets, transactions, settings, navigate } = useCoinBox();

  // Metrics calculation
  const totalAppsCount = apps.length;
  const totalWalletsCount = wallets.length;
  const totalUnits = wallets.reduce((acc, w) => acc + w.balance, 0);
  const totalEstimatedBrl = wallets.reduce((acc, w) => acc + w.balance * (w.exchangeRateToBrl || 0), 0);

  // Currency with highest balance
  const highestBalanceWallet = wallets.length > 0
    ? [...wallets].sort((a, b) => b.balance - a.balance)[0]
    : null;
  const highestWalletApp = highestBalanceWallet
    ? apps.find((a) => a.id === highestBalanceWallet.appId)
    : null;

  // Most active app by transaction count
  const appActivityMap: Record<string, number> = {};
  transactions.forEach((tx) => {
    appActivityMap[tx.appId] = (appActivityMap[tx.appId] || 0) + 1;
  });

  let mostActiveAppId = '';
  let maxTxCount = 0;
  Object.entries(appActivityMap).forEach(([appId, count]) => {
    if (count > maxTxCount) {
      maxTxCount = count;
      mostActiveAppId = appId;
    }
  });
  const mostActiveApp = apps.find((a) => a.id === mostActiveAppId) || apps[0];

  // Distribution by Currency Type
  const distributionByType: Record<string, { count: number; totalUnits: number; icon: string }> = {};
  wallets.forEach((w) => {
    if (!distributionByType[w.currencyType]) {
      distributionByType[w.currencyType] = { count: 0, totalUnits: 0, icon: w.icon };
    }
    distributionByType[w.currencyType].count += 1;
    distributionByType[w.currencyType].totalUnits += w.balance;
  });

  // Top 4 Currency Types
  const currencyBreakdown = Object.entries(distributionByType)
    .map(([type, data]) => ({ type, ...data }))
    .sort((a, b) => b.totalUnits - a.totalUnits)
    .slice(0, 5);

  const maxTypeUnits = Math.max(1, ...currencyBreakdown.map((c) => c.totalUnits));

  // Credits vs Debits volume
  const totalCredits = transactions
    .filter((t) => t.type === 'CREDIT' || t.type === 'SIMULATION_APPLY')
    .reduce((acc, t) => acc + t.amount, 0);
  const totalDebits = transactions
    .filter((t) => t.type === 'DEBIT')
    .reduce((acc, t) => acc + t.amount, 0);

  return (
    <div className="space-y-4 pb-8">
      {/* Overview Cards Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className={`p-3.5 rounded-2xl border ${
          settings.darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Apps</span>
            <Layers className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black font-mono tabular-nums mt-1 text-slate-100 dark:text-white">
            {totalAppsCount}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">{totalWalletsCount} carteiras ativas</p>
        </div>

        <div className={`p-3.5 rounded-2xl border ${
          settings.darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total de Moedas</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black font-mono tabular-nums mt-1 text-amber-400 truncate">
            {totalUnits.toLocaleString('pt-BR')}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">unidades registradas</p>
        </div>

        <div className={`p-3.5 rounded-2xl border col-span-2 ${
          settings.darkMode
            ? 'bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950/20 border-slate-700/80'
            : 'bg-gradient-to-r from-amber-50/50 to-orange-50/50 border-amber-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Patrimônio Virtual Estimado</span>
            <span className="text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-bold">
              Base Cotação
            </span>
          </div>
          <div className="text-2xl font-black font-mono tabular-nums text-emerald-400 mt-1">
            {settings.currencySymbol} {totalEstimatedBrl.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5 italic">
            Calculado com base nas taxas de conversão de cada moeda.
          </p>
        </div>
      </div>

      {/* Highlights: Top App & Top Currency */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {highestBalanceWallet && (
          <div className={`p-3.5 rounded-2xl border ${
            settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 mb-1">
              <Crown className="w-4 h-4" />
              <span>Moeda com Maior Saldo</span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{highestBalanceWallet.icon}</span>
                <div>
                  <div className="text-xs font-bold">{highestBalanceWallet.name}</div>
                  <div className="text-[10px] text-slate-400">{highestWalletApp?.appName}</div>
                </div>
              </div>
              <div className="text-sm font-black font-mono tabular-nums text-amber-400">
                {highestBalanceWallet.balance.toLocaleString('pt-BR')}
              </div>
            </div>
          </div>
        )}

        {mostActiveApp && (
          <div className={`p-3.5 rounded-2xl border ${
            settings.darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}>
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400 mb-1">
              <Flame className="w-4 h-4" />
              <span>App Mais Utilizado</span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-slate-800 overflow-hidden shrink-0 flex items-center justify-center">
                  {mostActiveApp.iconReference.startsWith('http') ? (
                    <img src={mostActiveApp.iconReference} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span>🎮</span>
                  )}
                </div>
                <div>
                  <div className="text-xs font-bold truncate max-w-[120px]">{mostActiveApp.appName}</div>
                  <div className="text-[10px] text-slate-400">{mostActiveApp.category}</div>
                </div>
              </div>
              <div className="text-xs font-semibold text-slate-300">
                {maxTxCount} {maxTxCount === 1 ? 'operação' : 'operações'}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* AdMob Banner for Stats placement */}
      <AdMobBannerView placement="Painel de Estatísticas" />

      {/* Lightweight SVG Charts Section (Prompt 10: Criar gráficos simples e leves) */}
      <div className={`p-4 rounded-3xl border ${
        settings.darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 flex items-center gap-1.5">
            <PieChart className="w-4 h-4 text-purple-400" />
            <span>Distribuição de Moedas por Categoria</span>
          </h3>
        </div>

        <div className="space-y-3">
          {currencyBreakdown.map((item) => {
            const percentage = Math.round((item.totalUnits / maxTypeUnits) * 100);
            return (
              <div key={item.type} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">{item.icon}</span>
                    <span className="font-semibold text-slate-200">{item.type}</span>
                    <span className="text-[10px] text-slate-500">({item.count} cart.)</span>
                  </div>
                  <span className="font-mono font-bold tabular-nums text-slate-300">
                    {item.totalUnits.toLocaleString('pt-BR')}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-all duration-500"
                    style={{ width: `${Math.max(5, percentage)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Cashflow Volume comparison (Credits vs Debits) */}
      <div className={`p-4 rounded-3xl border ${
        settings.darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-3 flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span>Fluxo Total Movimentado</span>
        </h3>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
            <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Ganhos / Entradas</span>
            </div>
            <div className="text-base font-black font-mono tabular-nums text-emerald-400 mt-1 truncate">
              +{totalCredits.toLocaleString('pt-BR')}
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20">
            <div className="flex items-center gap-1 text-[11px] font-bold text-rose-400">
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Gastos / Saídas</span>
            </div>
            <div className="text-base font-black font-mono tabular-nums text-rose-400 mt-1 truncate">
              -{totalDebits.toLocaleString('pt-BR')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
