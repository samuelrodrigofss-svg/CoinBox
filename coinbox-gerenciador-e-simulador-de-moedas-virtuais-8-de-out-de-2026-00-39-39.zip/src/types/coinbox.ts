/**
 * CoinBox Domain Models and Types
 * Corresponds to Room Entities and Domain Models in Clean Architecture
 */

export interface AppItem {
  id: string;
  packageName: string;
  appName: string;
  iconReference: string; // URL, SVG key or Material icon name
  category: string; // "Jogos", "Aplicativos", "Trabalho", "Outros"
  favorite: boolean;
  isInstalled: boolean;
  versionName?: string;
  createdAt: string;
  updatedAt: string;
}

export type CurrencyType =
  | 'Moedas'
  | 'Gemas'
  | 'Diamantes'
  | 'Pontos'
  | 'Fichas'
  | 'Vidas'
  | 'Energia'
  | 'Créditos'
  | 'Dinheiro'
  | 'Personalizado';

export interface WalletItem {
  id: string;
  appId: string;
  name: string;
  currencyType: CurrencyType;
  icon: string; // Emoji or icon key: 🪙, 💎, 🔷, ⭐, 🎲, ❤️, ⚡, 🎫, 💵
  balance: number;
  exchangeRateToBrl?: number; // e.g., 1 unit = R$ 0.01 (user-defined estimate)
  color?: string; // UI tint color
  createdAt: string;
  updatedAt: string;
}

export type TransactionType = 'CREDIT' | 'DEBIT' | 'SIMULATION_APPLY';

export interface TransactionItem {
  id: string;
  walletId: string;
  appId: string;
  appName: string;
  walletName: string;
  currencyIcon: string;
  type: TransactionType;
  amount: number;
  previousBalance: number;
  newBalance: number;
  description: string;
  createdAt: string; // ISO format or Brazilian formatted date
}

export interface CategoryItem {
  id: string;
  name: string;
  icon: string;
  createdAt: string;
}

export interface SettingsState {
  darkMode: boolean;
  notifications: boolean;
  currencySymbol: string; // "R$", "$", "€"
  allowNegativeBalance: boolean;
  simulationModeEnabled: boolean;
  soundEffects: boolean;
  isPremium: boolean;
  showAdMobBanner: boolean;
  hasCompletedOnboarding: boolean;
}

export interface BackupData {
  version: number;
  exportDate: string;
  appName: string;
  apps: AppItem[];
  wallets: WalletItem[];
  transactions: TransactionItem[];
  categories: CategoryItem[];
  settings: Partial<SettingsState>;
}
