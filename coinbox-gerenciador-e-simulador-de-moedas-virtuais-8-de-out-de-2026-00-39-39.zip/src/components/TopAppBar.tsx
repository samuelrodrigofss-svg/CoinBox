import React from 'react';
import { ArrowLeft, Sparkles, Code2, ShieldCheck } from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

interface TopAppBarProps {
  title: string;
  subtitle?: string;
  showBackButton?: boolean;
  onBack?: () => void;
  actions?: React.ReactNode;
  onOpenCodeExplorer?: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  title,
  subtitle,
  showBackButton = false,
  onBack,
  actions,
  onOpenCodeExplorer,
}) => {
  const { goBack, settings } = useCoinBox();

  return (
    <header className={`sticky top-0 z-30 px-4 py-3 border-b transition-colors ${
      settings.darkMode ? 'bg-slate-900/90 border-slate-800 text-slate-100' : 'bg-white/95 border-slate-200 text-slate-900'
    } backdrop-blur-md flex items-center justify-between min-h-[58px]`}>
      <div className="flex items-center gap-2.5 min-w-0">
        {showBackButton && (
          <button
            onClick={onBack || goBack}
            className={`p-2 -ml-1 rounded-xl transition-colors active:scale-95 ${
              settings.darkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-700'
            }`}
            title="Voltar"
            aria-label="Voltar"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold tracking-tight truncate leading-tight">
              {title}
            </h1>
            {settings.isPremium && (
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                PRO
              </span>
            )}
          </div>
          {subtitle && (
            <p className={`text-xs truncate ${settings.darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {subtitle}
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        {onOpenCodeExplorer && (
          <button
            onClick={onOpenCodeExplorer}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              settings.darkMode
                ? 'bg-cyan-950/40 border-cyan-800/60 text-cyan-300 hover:bg-cyan-900/40'
                : 'bg-cyan-50 border-cyan-200 text-cyan-800 hover:bg-cyan-100'
            }`}
            title="Ver Código Fonte Android Kotlin"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Kotlin/Compose</span>
          </button>
        )}
        {actions}
      </div>
    </header>
  );
};
