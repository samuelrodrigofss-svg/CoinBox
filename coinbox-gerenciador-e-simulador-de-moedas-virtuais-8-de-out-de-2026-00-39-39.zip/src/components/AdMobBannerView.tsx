import React from 'react';
import { Sparkles, Info, X } from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

interface AdMobBannerViewProps {
  placement?: string;
}

export const AdMobBannerView: React.FC<AdMobBannerViewProps> = ({ placement = 'Geral' }) => {
  const { settings, updateSettings, togglePremium } = useCoinBox();

  if (settings.isPremium || !settings.showAdMobBanner) {
    return null;
  }

  return (
    <div className="w-full my-3 px-1">
      <div className={`relative overflow-hidden rounded-xl border p-2.5 transition-all text-xs ${
        settings.darkMode
          ? 'bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-slate-700/80 text-slate-300'
          : 'bg-gradient-to-r from-slate-50 via-amber-50/40 to-slate-50 border-amber-200/70 text-slate-700'
      }`}>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <span className="shrink-0 px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wide uppercase bg-amber-500/20 text-amber-500 border border-amber-500/30">
              Anúncio Teste AdMob
            </span>
            <span className="truncate text-[11px] font-medium opacity-90">
              ID: ca-app-pub-3940256099942544/6300978111 • {placement}
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={togglePremium}
              className="flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors shadow-sm"
              title="Ativar CoinBox PRO sem anúncios"
            >
              <Sparkles className="w-3 h-3" />
              <span>Remover Anúncios</span>
            </button>
            <button
              onClick={() => updateSettings({ showAdMobBanner: false })}
              className="p-1 rounded text-slate-400 hover:text-slate-200 transition-colors"
              title="Fechar banner de teste"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
