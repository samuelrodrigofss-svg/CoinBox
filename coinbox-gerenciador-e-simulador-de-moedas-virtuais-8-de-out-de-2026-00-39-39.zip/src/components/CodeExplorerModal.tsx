import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  FileCode,
  Folder,
  X,
  ExternalLink,
  ShieldCheck,
  Smartphone,
  Layers,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES, CodeFile } from '../data/androidProjectCode';

interface CodeExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeExplorerModal: React.FC<CodeExplorerModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(ANDROID_PROJECT_FILES[3]); // Entities.kt
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-4xl h-[90vh] bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Modal Top Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold tracking-tight">
                  Código Fonte Android Kotlin & Clean Architecture
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                  Android Studio Ready
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Jetpack Compose Material 3 • Room Database • Kotlin Coroutines Flow • MVVM
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Explorer Content */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0">
          {/* Left Sidebar: File Tree */}
          <div className="w-full md:w-72 border-r border-slate-800 bg-slate-950/40 p-3 overflow-y-auto shrink-0">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 px-2 py-1 mb-1">
              Arquivos do Projeto Android
            </div>
            <div className="space-y-1">
              {ANDROID_PROJECT_FILES.map((file) => {
                const isSelected = selectedFile.path === file.path;
                const fileName = file.path.split('/').pop() || file.path;

                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-2 rounded-xl text-xs transition-all flex items-start gap-2 ${
                      isSelected
                        ? 'bg-cyan-500/15 text-cyan-300 font-bold border border-cyan-500/30'
                        : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                    }`}
                  >
                    <FileCode className="w-4 h-4 shrink-0 mt-0.5 text-slate-400" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-mono text-[11px]">{fileName}</div>
                      <div className="text-[10px] text-slate-500 truncate font-sans">
                        {file.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Architecture Badge */}
            <div className="mt-4 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-[11px] space-y-2">
              <div className="font-bold text-amber-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Padrão 100% Oficial</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-[10px]">
                Compatível com Google Play Store. Utiliza PackageManager oficial para listar apps, banco Room local seguro e sem permissões invasivas ou modificação de arquivos de terceiros.
              </p>
            </div>
          </div>

          {/* Right Area: Code Viewer */}
          <div className="flex-1 flex flex-col min-w-0 bg-slate-950/80">
            {/* Action Bar for Code */}
            <div className="px-4 py-2.5 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
              <div className="min-w-0">
                <span className="font-mono text-xs font-semibold text-cyan-400">
                  {selectedFile.path}
                </span>
                <span className="text-xs text-slate-500 ml-2">({selectedFile.language})</span>
              </div>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors active:scale-95"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Arquivo</span>
                  </>
                )}
              </button>
            </div>

            {/* Code container */}
            <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-300 leading-relaxed bg-slate-950 selection:bg-cyan-500/20 selection:text-cyan-300">
              <pre className="whitespace-pre">{selectedFile.content}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
