import React from 'react';
import { Home, Layers, Clock, BarChart3, Settings } from 'lucide-react';
import { useCoinBox, ScreenType } from '../context/CoinBoxContext';

export const BottomNavBar: React.FC = () => {
  const { currentScreen, navigate, settings } = useCoinBox();

  const navItems: { label: string; screen: ScreenType; icon: React.FC<{ className?: string }> }[] = [
    { label: 'Início', screen: 'home', icon: Home },
    { label: 'Apps', screen: 'apps', icon: Layers },
    { label: 'Histórico', screen: 'history', icon: Clock },
    { label: 'Dashboard', screen: 'dashboard', icon: BarChart3 },
    { label: 'Ajustes', screen: 'settings', icon: Settings },
  ];

  return (
    <nav
      className={`shrink-0 z-20 border-t px-2 py-1.5 transition-colors ${
        settings.darkMode
          ? 'bg-slate-900/95 border-slate-800/80 text-slate-400'
          : 'bg-white/95 border-slate-200 text-slate-600'
      } backdrop-blur-md`}
      aria-label="Navegação Principal"
    >
      <div className="grid grid-cols-5 items-center">
        {navItems.map((item) => {
          const isActive = currentScreen === item.screen;
          const Icon = item.icon;

          return (
            <button
              key={item.screen}
              onClick={() => navigate(item.screen)}
              className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all active:scale-95 min-h-[46px] ${
                isActive
                  ? settings.darkMode
                    ? 'text-amber-400 font-semibold'
                    : 'text-amber-600 font-semibold'
                  : 'hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-colors ${
                  isActive
                    ? settings.darkMode
                      ? 'bg-amber-400/15'
                      : 'bg-amber-100'
                    : 'bg-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span className="text-[10px] tracking-tight mt-0.5 leading-none">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
