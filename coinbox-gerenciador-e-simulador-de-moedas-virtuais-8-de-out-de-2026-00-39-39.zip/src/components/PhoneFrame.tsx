import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Maximize2,
  Minimize2,
  Wifi,
  Battery,
  Sparkles,
  Code2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { useCoinBox } from '../context/CoinBoxContext';

interface PhoneFrameProps {
  children: React.ReactNode;
  onOpenCodeExplorer: () => void;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ children, onOpenCodeExplorer }) => {
  const { settings, notificationToast } = useCoinBox();
  const [isPhoneView, setIsPhoneView] = useState(true);
  const [currentTime, setCurrentTime] = useState('12:45');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`min-h-screen flex flex-col items-center justify-start p-2 sm:p-4 md:p-6 transition-colors ${
      settings.darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
    }`}>
      {/* Top Utility Bar for the AI Studio web tester */}
      <div className="w-full max-w-5xl mb-3 flex flex-wrap items-center justify-between gap-2 px-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-base">
            🪙
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm tracking-tight">CoinBox</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                Android 14+ Jetpack Compose
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Clean Architecture • Room Database • Kotlin Coroutines Flow • MVVM
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenCodeExplorer}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/25 transition-all active:scale-95 shadow-sm"
          >
            <Code2 className="w-4 h-4" />
            <span>Código Kotlin / Room</span>
          </button>

          <button
            onClick={() => setIsPhoneView(!isPhoneView)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
              settings.darkMode
                ? 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
            }`}
            title={isPhoneView ? 'Alternar para Tela Cheia' : 'Alternar para Moldura de Celular'}
          >
            {isPhoneView ? <Maximize2 className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">
              {isPhoneView ? 'Modo Expandido' : 'Modo Celular'}
            </span>
          </button>
        </div>
      </div>

      {/* Main Container: either Phone Frame or Full-Width */}
      <div
        className={`w-full transition-all duration-300 flex flex-col ${
          isPhoneView
            ? 'max-w-[420px] h-[840px] max-h-[92vh] rounded-[44px] shadow-2xl border-[10px] relative overflow-hidden ring-1'
            : 'max-w-4xl min-h-[800px] rounded-3xl shadow-xl border overflow-hidden'
        } ${
          settings.darkMode
            ? 'bg-slate-950 border-slate-800 ring-slate-700/50'
            : 'bg-white border-slate-300 ring-slate-200'
        }`}
      >
        {/* Android Status Bar (Shown in Phone View) */}
        {isPhoneView && (
          <div className={`px-6 pt-2 pb-1 flex items-center justify-between text-xs select-none shrink-0 z-40 transition-colors ${
            settings.darkMode ? 'bg-slate-950 text-slate-300' : 'bg-white text-slate-700'
          }`}>
            <span className="font-semibold text-[13px] tracking-tight font-mono">{currentTime}</span>

            {/* Camera Punch-hole */}
            <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-800 shadow-inner -mt-1" />

            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-bold tracking-tighter opacity-80">5G</span>
              <Wifi className="w-3.5 h-3.5" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px] font-mono">98%</span>
                <Battery className="w-4 h-4 fill-current" />
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Toast / Notification banner */}
        {notificationToast && (
          <div className="absolute top-12 left-4 right-4 z-50 animate-bounce">
            <div className="py-2 px-3.5 rounded-2xl bg-slate-900/95 border border-amber-500/50 text-amber-300 shadow-2xl backdrop-blur-md text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="truncate">{notificationToast}</span>
            </div>
          </div>
        )}

        {/* Scrollable Screen Content Container */}
        <div className="flex-1 overflow-y-auto flex flex-col relative">{children}</div>

        {/* Android Gesture Bar at bottom (Phone view) */}
        {isPhoneView && (
          <div className={`py-1.5 flex justify-center shrink-0 z-30 ${
            settings.darkMode ? 'bg-slate-950' : 'bg-white'
          }`}>
            <div className="w-32 h-1 rounded-full bg-slate-400/40" />
          </div>
        )}
      </div>
    </div>
  );
};
