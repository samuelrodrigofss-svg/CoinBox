import React, { useState } from 'react';
import { CoinBoxProvider, useCoinBox } from './context/CoinBoxContext';
import { PhoneFrame } from './components/PhoneFrame';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar } from './components/BottomNavBar';
import { CodeExplorerModal } from './components/CodeExplorerModal';

import { OnboardingScreen } from './screens/OnboardingScreen';
import { HomeScreen } from './screens/HomeScreen';
import { AppsListScreen } from './screens/AppsListScreen';
import { AppDetailScreen } from './screens/AppDetailScreen';
import { AddBalanceScreen } from './screens/AddBalanceScreen';
import { RemoveBalanceScreen } from './screens/RemoveBalanceScreen';
import { SimulationScreen } from './screens/SimulationScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import { SettingsScreen } from './screens/SettingsScreen';

const ScreenContent: React.FC<{ onOpenCodeExplorer: () => void }> = ({ onOpenCodeExplorer }) => {
  const { currentScreen, apps, screenParams } = useCoinBox();

  // Determine top bar titles and configuration
  const getScreenConfig = () => {
    switch (currentScreen) {
      case 'onboarding':
        return { title: 'CoinBox', showTop: false, showBottom: false, showBack: false };
      case 'home':
        return { title: 'CoinBox', subtitle: 'Carteira & Simulador', showTop: true, showBottom: true, showBack: false };
      case 'apps':
        return { title: 'Aplicativos & Jogos', subtitle: 'Catálogo de Carteiras', showTop: true, showBottom: true, showBack: false };
      case 'app_detail': {
        const currentApp = apps.find((a) => a.id === screenParams.appId);
        return {
          title: currentApp?.appName || 'Detalhes do App',
          subtitle: currentApp?.category || 'Carteira Virtual',
          showTop: true,
          showBottom: false,
          showBack: true,
        };
      }
      case 'add_balance':
        return { title: 'Adicionar Saldo', subtitle: 'Depósito Virtual', showTop: true, showBottom: false, showBack: true };
      case 'remove_balance':
        return { title: 'Remover Saldo', subtitle: 'Resgate / Débito', showTop: true, showBottom: false, showBack: true };
      case 'simulation':
        return { title: 'Modo Simulação', subtitle: 'Sandbox Não Destrutivo', showTop: true, showBottom: false, showBack: true };
      case 'history':
        return { title: 'Histórico de Operações', subtitle: 'Livro-Razão de Saldos', showTop: true, showBottom: true, showBack: false };
      case 'dashboard':
        return { title: 'Dashboard & Estatísticas', subtitle: 'Métricas e Distribuição', showTop: true, showBottom: true, showBack: false };
      case 'settings':
        return { title: 'Configurações', subtitle: 'Preferências e Backup', showTop: true, showBottom: true, showBack: false };
      default:
        return { title: 'CoinBox', showTop: true, showBottom: true, showBack: false };
    }
  };

  const config = getScreenConfig();

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {config.showTop && (
        <TopAppBar
          title={config.title}
          subtitle={config.subtitle}
          showBackButton={config.showBack}
          onOpenCodeExplorer={onOpenCodeExplorer}
        />
      )}

      {/* Screen Body */}
      <main className="flex-1 overflow-y-auto px-4 py-3">
        {currentScreen === 'onboarding' && <OnboardingScreen />}
        {currentScreen === 'home' && <HomeScreen />}
        {currentScreen === 'apps' && <AppsListScreen />}
        {currentScreen === 'app_detail' && <AppDetailScreen />}
        {currentScreen === 'add_balance' && <AddBalanceScreen />}
        {currentScreen === 'remove_balance' && <RemoveBalanceScreen />}
        {currentScreen === 'simulation' && <SimulationScreen />}
        {currentScreen === 'history' && <HistoryScreen />}
        {currentScreen === 'dashboard' && <DashboardScreen />}
        {currentScreen === 'settings' && <SettingsScreen />}
      </main>

      {config.showBottom && <BottomNavBar />}
    </div>
  );
};

export default function App() {
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);

  return (
    <CoinBoxProvider>
      <PhoneFrame onOpenCodeExplorer={() => setIsCodeModalOpen(true)}>
        <ScreenContent onOpenCodeExplorer={() => setIsCodeModalOpen(true)} />
      </PhoneFrame>

      <CodeExplorerModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
    </CoinBoxProvider>
  );
}
