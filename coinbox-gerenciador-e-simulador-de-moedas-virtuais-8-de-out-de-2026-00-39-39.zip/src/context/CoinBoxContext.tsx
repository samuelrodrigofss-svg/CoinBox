import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  AppItem,
  WalletItem,
  TransactionItem,
  CategoryItem,
  SettingsState,
  BackupData,
} from '../types/coinbox';
import {
  DEVICE_INSTALLED_APPS,
  INITIAL_WALLETS,
  INITIAL_TRANSACTIONS,
  INITIAL_CATEGORIES,
  INITIAL_SETTINGS,
  playSound,
} from '../data/mockData';

export type ScreenType =
  | 'onboarding'
  | 'home'
  | 'apps'
  | 'app_detail'
  | 'wallet_detail'
  | 'add_balance'
  | 'remove_balance'
  | 'history'
  | 'dashboard'
  | 'simulation'
  | 'settings'
  | 'about'
  | 'source_code';

interface NavigationEntry {
  screen: ScreenType;
  params?: Record<string, string>;
}

interface CoinBoxContextValue {
  apps: AppItem[];
  installedDeviceApps: AppItem[];
  wallets: WalletItem[];
  transactions: TransactionItem[];
  categories: CategoryItem[];
  settings: SettingsState;
  currentScreen: ScreenType;
  screenParams: Record<string, string>;
  simulatedBalances: Record<string, number>; // walletId -> simulatedBalance
  notificationToast: string | null;

  // Navigation
  navigate: (screen: ScreenType, params?: Record<string, string>) => void;
  goBack: () => void;
  showToast: (msg: string) => void;

  // App Actions
  toggleFavoriteApp: (appId: string) => void;
  registerAppFromDevice: (deviceApp: AppItem) => void;
  createCustomApp: (appName: string, packageName: string, category: string, iconUrl?: string) => AppItem;
  deleteApp: (appId: string) => void;

  // Wallet Actions
  createWallet: (
    appId: string,
    name: string,
    currencyType: WalletItem['currencyType'],
    icon: string,
    initialBalance: number,
    exchangeRateToBrl?: number,
    color?: string
  ) => WalletItem;
  deleteWallet: (walletId: string) => void;
  updateWalletRate: (walletId: string, newRate: number) => void;

  // Balance Operations (Add / Remove)
  addBalance: (walletId: string, amount: number, description?: string) => { success: boolean; message: string };
  removeBalance: (walletId: string, amount: number, description?: string) => { success: boolean; message: string };

  // Simulation Mode
  setSimulatedAmount: (walletId: string, newSimulation: number) => void;
  commitSimulation: (walletId: string) => void;
  discardSimulation: (walletId: string) => void;

  // Transactions
  deleteTransaction: (id: string) => void;
  clearTransactions: (appId?: string) => void;

  // Categories & Settings
  addCategory: (name: string, icon: string) => void;
  updateSettings: (updates: Partial<SettingsState>) => void;
  togglePremium: () => void;

  // Backup & Export
  generateExport: (format: 'json' | 'csv' | 'txt') => string;
  importBackupJson: (jsonString: string) => { success: boolean; error?: string };
  resetDatabase: () => void;
}

const STORAGE_KEY_PREFIX = 'coinbox_db_v1_';

const CoinBoxContext = createContext<CoinBoxContextValue | null>(null);

export const CoinBoxProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial states from localStorage with safe fallbacks
  const [apps, setApps] = useState<AppItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}apps`);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    // By default, Free Fire, Roblox, Subway Surfers and Duolingo are registered in CoinBox
    return DEVICE_INSTALLED_APPS.filter((a) =>
      ['app_free_fire', 'app_roblox', 'app_subway_surfers', 'app_duolingo'].includes(a.id)
    );
  });

  const [installedDeviceApps] = useState<AppItem[]>(DEVICE_INSTALLED_APPS);

  const [wallets, setWallets] = useState<WalletItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}wallets`);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_WALLETS;
  });

  const [transactions, setTransactions] = useState<TransactionItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}transactions`);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_TRANSACTIONS;
  });

  const [categories, setCategories] = useState<CategoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}categories`);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_CATEGORIES;
  });

  const [settings, setSettings] = useState<SettingsState>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}settings`);
      if (saved) return { ...INITIAL_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // fallback
    }
    return INITIAL_SETTINGS;
  });

  const [navHistory, setNavHistory] = useState<NavigationEntry[]>([
    { screen: INITIAL_SETTINGS.hasCompletedOnboarding ? 'home' : 'onboarding', params: {} },
  ]);

  const [simulatedBalances, setSimulatedBalances] = useState<Record<string, number>>({});
  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  const currentNav = navHistory[navHistory.length - 1] || { screen: 'home', params: {} };
  const currentScreen = currentNav.screen;
  const screenParams = currentNav.params || {};

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}apps`, JSON.stringify(apps));
    } catch {}
  }, [apps]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}wallets`, JSON.stringify(wallets));
    } catch {}
  }, [wallets]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}transactions`, JSON.stringify(transactions));
    } catch {}
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}categories`, JSON.stringify(categories));
    } catch {}
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}settings`, JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Toast notification helper
  const showToast = useCallback((msg: string) => {
    setNotificationToast(msg);
    const timer = setTimeout(() => {
      setNotificationToast(null);
    }, 3200);
    return () => clearTimeout(timer);
  }, []);

  // Navigation
  const navigate = useCallback(
    (screen: ScreenType, params: Record<string, string> = {}) => {
      if (settings.soundEffects) playSound('click');
      setNavHistory((prev) => [...prev, { screen, params }]);
    },
    [settings.soundEffects]
  );

  const goBack = useCallback(() => {
    if (settings.soundEffects) playSound('click');
    setNavHistory((prev) => (prev.length > 1 ? prev.slice(0, prev.length - 1) : prev));
  }, [settings.soundEffects]);

  // App Actions
  const toggleFavoriteApp = useCallback(
    (appId: string) => {
      if (settings.soundEffects) playSound('click');
      setApps((prev) =>
        prev.map((app) => (app.id === appId ? { ...app, favorite: !app.favorite, updatedAt: new Date().toISOString() } : app))
      );
    },
    [settings.soundEffects]
  );

  const registerAppFromDevice = useCallback(
    (deviceApp: AppItem) => {
      if (settings.soundEffects) playSound('success');
      const alreadyExists = apps.some((a) => a.id === deviceApp.id || a.packageName === deviceApp.packageName);
      if (alreadyExists) {
        showToast(`O aplicativo "${deviceApp.appName}" já está cadastrado no CoinBox.`);
        return;
      }
      const newApp: AppItem = {
        ...deviceApp,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setApps((prev) => [newApp, ...prev]);

      // Seed a default starter coin wallet for user convenience
      const defaultWallet: WalletItem = {
        id: `w_${Date.now()}`,
        appId: newApp.id,
        name: 'Moedas Virtuais',
        currencyType: 'Moedas',
        icon: '🪙',
        balance: 1000,
        exchangeRateToBrl: 0.01,
        color: '#f59e0b',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setWallets((prev) => [...prev, defaultWallet]);
      showToast(`Aplicativo "${deviceApp.appName}" cadastrado com sucesso!`);
    },
    [apps, settings.soundEffects, showToast]
  );

  const createCustomApp = useCallback(
    (appName: string, packageName: string, category: string, iconUrl?: string): AppItem => {
      if (settings.soundEffects) playSound('success');
      const newApp: AppItem = {
        id: `app_${Date.now()}`,
        packageName: packageName.trim() || `com.custom.${Date.now()}`,
        appName: appName.trim(),
        iconReference:
          iconUrl ||
          'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&auto=format&fit=crop&q=80',
        category: category || 'Jogos',
        favorite: false,
        isInstalled: true,
        versionName: '1.0.0',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setApps((prev) => [newApp, ...prev]);

      // Default wallet
      const initialWallet: WalletItem = {
        id: `w_${Date.now()}`,
        appId: newApp.id,
        name: 'Moedas',
        currencyType: 'Moedas',
        icon: '🪙',
        balance: 500,
        exchangeRateToBrl: 0.01,
        color: '#eab308',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setWallets((prev) => [...prev, initialWallet]);
      showToast(`Aplicativo "${appName}" criado com carteira inicial!`);
      return newApp;
    },
    [settings.soundEffects, showToast]
  );

  const deleteApp = useCallback(
    (appId: string) => {
      if (settings.soundEffects) playSound('click');
      const targetApp = apps.find((a) => a.id === appId);
      setApps((prev) => prev.filter((a) => a.id !== appId));
      setWallets((prev) => prev.filter((w) => w.appId !== appId));
      setTransactions((prev) => prev.filter((t) => t.appId !== appId));
      showToast(`Aplicativo ${targetApp?.appName || ''} removido.`);
    },
    [apps, settings.soundEffects, showToast]
  );

  // Wallet Actions
  const createWallet = useCallback(
    (
      appId: string,
      name: string,
      currencyType: WalletItem['currencyType'],
      icon: string,
      initialBalance: number,
      exchangeRateToBrl: number = 0.01,
      color: string = '#06b6d4'
    ): WalletItem => {
      if (settings.soundEffects) playSound('success');
      const newWallet: WalletItem = {
        id: `w_${Date.now()}`,
        appId,
        name,
        currencyType,
        icon,
        balance: initialBalance,
        exchangeRateToBrl,
        color,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setWallets((prev) => [...prev, newWallet]);

      if (initialBalance > 0) {
        const targetApp = apps.find((a) => a.id === appId);
        const tx: TransactionItem = {
          id: `tx_${Date.now()}`,
          walletId: newWallet.id,
          appId,
          appName: targetApp?.appName || 'Aplicativo',
          walletName: name,
          currencyIcon: icon,
          type: 'CREDIT',
          amount: initialBalance,
          previousBalance: 0,
          newBalance: initialBalance,
          description: 'Criação de carteira com saldo inicial',
          createdAt: new Date().toISOString(),
        };
        setTransactions((prev) => [tx, ...prev]);
      }

      showToast(`Carteira "${name}" criada com sucesso!`);
      return newWallet;
    },
    [apps, settings.soundEffects, showToast]
  );

  const deleteWallet = useCallback(
    (walletId: string) => {
      if (settings.soundEffects) playSound('click');
      setWallets((prev) => prev.filter((w) => w.id !== walletId));
      setTransactions((prev) => prev.filter((t) => t.walletId !== walletId));
      showToast('Carteira removida.');
    },
    [settings.soundEffects, showToast]
  );

  const updateWalletRate = useCallback(
    (walletId: string, newRate: number) => {
      setWallets((prev) =>
        prev.map((w) =>
          w.id === walletId ? { ...w, exchangeRateToBrl: newRate, updatedAt: new Date().toISOString() } : w
        )
      );
      showToast('Taxa estimada atualizada com sucesso.');
    },
    [showToast]
  );

  // Add Balance
  const addBalance = useCallback(
    (walletId: string, amount: number, description: string = ''): { success: boolean; message: string } => {
      if (isNaN(amount) || amount <= 0) {
        if (settings.soundEffects) playSound('error');
        return { success: false, message: 'Digite uma quantidade válida maior que zero.' };
      }

      const wallet = wallets.find((w) => w.id === walletId);
      if (!wallet) {
        if (settings.soundEffects) playSound('error');
        return { success: false, message: 'Carteira não encontrada.' };
      }

      const targetApp = apps.find((a) => a.id === wallet.appId);
      const prevBal = wallet.balance;
      const newBal = prevBal + amount;

      setWallets((prev) =>
        prev.map((w) => (w.id === walletId ? { ...w, balance: newBal, updatedAt: new Date().toISOString() } : w))
      );

      const tx: TransactionItem = {
        id: `tx_${Date.now()}`,
        walletId: wallet.id,
        appId: wallet.appId,
        appName: targetApp?.appName || 'App',
        walletName: wallet.name,
        currencyIcon: wallet.icon,
        type: 'CREDIT',
        amount,
        previousBalance: prevBal,
        newBalance: newBal,
        description: description.trim() || 'Depósito de saldo manual',
        createdAt: new Date().toISOString(),
      };

      setTransactions((prev) => [tx, ...prev]);
      if (settings.soundEffects) playSound('credit');

      if (settings.notifications) {
        showToast(`+${amount.toLocaleString('pt-BR')} ${wallet.icon} adicionados em ${targetApp?.appName || wallet.name}!`);
      }
      return { success: true, message: 'Saldo adicionado com sucesso!' };
    },
    [wallets, apps, settings.soundEffects, settings.notifications, showToast]
  );

  // Remove Balance
  const removeBalance = useCallback(
    (walletId: string, amount: number, description: string = ''): { success: boolean; message: string } => {
      if (isNaN(amount) || amount <= 0) {
        if (settings.soundEffects) playSound('error');
        return { success: false, message: 'Digite uma quantidade válida maior que zero.' };
      }

      const wallet = wallets.find((w) => w.id === walletId);
      if (!wallet) {
        if (settings.soundEffects) playSound('error');
        return { success: false, message: 'Carteira não encontrada.' };
      }

      const prevBal = wallet.balance;
      const newBal = prevBal - amount;

      if (newBal < 0 && !settings.allowNegativeBalance) {
        if (settings.soundEffects) playSound('error');
        return {
          success: false,
          message: `Saldo insuficiente! Saldo atual é de ${prevBal.toLocaleString('pt-BR')}. Habilite saldo negativo em Configurações se desejado.`,
        };
      }

      const targetApp = apps.find((a) => a.id === wallet.appId);

      setWallets((prev) =>
        prev.map((w) => (w.id === walletId ? { ...w, balance: newBal, updatedAt: new Date().toISOString() } : w))
      );

      const tx: TransactionItem = {
        id: `tx_${Date.now()}`,
        walletId: wallet.id,
        appId: wallet.appId,
        appName: targetApp?.appName || 'App',
        walletName: wallet.name,
        currencyIcon: wallet.icon,
        type: 'DEBIT',
        amount,
        previousBalance: prevBal,
        newBalance: newBal,
        description: description.trim() || 'Resgate / Saída de saldo manual',
        createdAt: new Date().toISOString(),
      };

      setTransactions((prev) => [tx, ...prev]);
      if (settings.soundEffects) playSound('debit');

      if (settings.notifications) {
        showToast(`-${amount.toLocaleString('pt-BR')} ${wallet.icon} removidos de ${targetApp?.appName || wallet.name}!`);
      }
      return { success: true, message: 'Saldo removido com sucesso!' };
    },
    [wallets, apps, settings.soundEffects, settings.allowNegativeBalance, settings.notifications, showToast]
  );

  // Simulation Mode Actions
  const setSimulatedAmount = useCallback((walletId: string, newSimulation: number) => {
    setSimulatedBalances((prev) => ({
      ...prev,
      [walletId]: newSimulation,
    }));
  }, []);

  const commitSimulation = useCallback(
    (walletId: string) => {
      const simulatedBal = simulatedBalances[walletId];
      if (simulatedBal === undefined) return;
      const wallet = wallets.find((w) => w.id === walletId);
      if (!wallet) return;

      const prevBal = wallet.balance;
      const diff = simulatedBal - prevBal;

      setWallets((prev) =>
        prev.map((w) =>
          w.id === walletId ? { ...w, balance: simulatedBal, updatedAt: new Date().toISOString() } : w
        )
      );

      const targetApp = apps.find((a) => a.id === wallet.appId);
      const tx: TransactionItem = {
        id: `tx_${Date.now()}`,
        walletId: wallet.id,
        appId: wallet.appId,
        appName: targetApp?.appName || 'App',
        walletName: wallet.name,
        currencyIcon: wallet.icon,
        type: 'SIMULATION_APPLY',
        amount: Math.abs(diff),
        previousBalance: prevBal,
        newBalance: simulatedBal,
        description: `Simulação aplicada: ${diff >= 0 ? '+' : '-'}${Math.abs(diff).toLocaleString('pt-BR')}`,
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [tx, ...prev]);

      // Remove from simulation map
      setSimulatedBalances((prev) => {
        const copy = { ...prev };
        delete copy[walletId];
        return copy;
      });

      if (settings.soundEffects) playSound('success');
      showToast('Simulação aplicada e salva como saldo real da carteira!');
    },
    [simulatedBalances, wallets, apps, settings.soundEffects, showToast]
  );

  const discardSimulation = useCallback(
    (walletId: string) => {
      setSimulatedBalances((prev) => {
        const copy = { ...prev };
        delete copy[walletId];
        return copy;
      });
      if (settings.soundEffects) playSound('click');
      showToast('Simulação descartada.');
    },
    [settings.soundEffects, showToast]
  );

  // Transactions
  const deleteTransaction = useCallback(
    (id: string) => {
      if (settings.soundEffects) playSound('click');
      setTransactions((prev) => prev.filter((t) => t.id !== id));
      showToast('Registro excluído do histórico.');
    },
    [settings.soundEffects, showToast]
  );

  const clearTransactions = useCallback(
    (appId?: string) => {
      if (settings.soundEffects) playSound('click');
      if (appId) {
        setTransactions((prev) => prev.filter((t) => t.appId !== appId));
        showToast('Histórico do aplicativo limpo.');
      } else {
        setTransactions([]);
        showToast('Todo o histórico foi limpo.');
      }
    },
    [settings.soundEffects, showToast]
  );

  // Categories & Settings
  const addCategory = useCallback(
    (name: string, icon: string) => {
      if (!name.trim()) return;
      if (settings.soundEffects) playSound('success');
      const newCat: CategoryItem = {
        id: `cat_${Date.now()}`,
        name: name.trim(),
        icon: icon || '🏷️',
        createdAt: new Date().toISOString(),
      };
      setCategories((prev) => [...prev, newCat]);
      showToast(`Categoria "${name}" adicionada!`);
    },
    [settings.soundEffects, showToast]
  );

  const updateSettings = useCallback((updates: Partial<SettingsState>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  }, []);

  const togglePremium = useCallback(() => {
    setSettings((prev) => {
      const next = !prev.isPremium;
      return {
        ...prev,
        isPremium: next,
        showAdMobBanner: next ? false : prev.showAdMobBanner,
      };
    });
    if (settings.soundEffects) playSound('success');
  }, [settings.soundEffects]);

  // Export
  const generateExport = useCallback(
    (format: 'json' | 'csv' | 'txt'): string => {
      if (format === 'json') {
        const backup: BackupData = {
          version: 1,
          exportDate: new Date().toISOString(),
          appName: 'CoinBox Android',
          apps,
          wallets,
          transactions,
          categories,
          settings,
        };
        return JSON.stringify(backup, null, 2);
      }

      if (format === 'csv') {
        const header = 'ID,Data,Aplicativo,Carteira,Tipo,Valor,Saldo_Anterior,Saldo_Novo,Descricao\n';
        const rows = transactions
          .map((t) =>
            [
              t.id,
              t.createdAt,
              `"${t.appName.replace(/"/g, '""')}"`,
              `"${t.walletName.replace(/"/g, '""')}"`,
              t.type,
              t.amount,
              t.previousBalance,
              t.newBalance,
              `"${t.description.replace(/"/g, '""')}"`,
            ].join(',')
          )
          .join('\n');
        return header + rows;
      }

      // Format TXT
      let txt = `========================================\n`;
      txt += `RELATÓRIO DE CARTEIRAS COINBOX\n`;
      txt += `Data: ${new Date().toLocaleString('pt-BR')}\n`;
      txt += `Aplicativos Cadastrados: ${apps.length}\n`;
      txt += `Total de Carteiras: ${wallets.length}\n`;
      txt += `========================================\n\n`;

      apps.forEach((app) => {
        txt += `[${app.appName}] (${app.category})\n`;
        const appWallets = wallets.filter((w) => w.appId === app.id);
        appWallets.forEach((w) => {
          txt += `  - ${w.icon} ${w.name}: ${w.balance.toLocaleString('pt-BR')} (Est. R$ ${(
            w.balance * (w.exchangeRateToBrl || 0)
          ).toFixed(2)})\n`;
        });
        txt += `\n`;
      });

      txt += `--- HISTÓRICO DE OPERAÇÕES RECENTES ---\n`;
      transactions.slice(0, 30).forEach((t) => {
        const sign = t.type === 'CREDIT' ? '+' : '-';
        txt += `${t.createdAt.slice(0, 10)} | ${t.appName} | ${t.currencyIcon} ${sign}${t.amount.toLocaleString(
          'pt-BR'
        )} => Saldo: ${t.newBalance.toLocaleString('pt-BR')} | ${t.description}\n`;
      });

      return txt;
    },
    [apps, wallets, transactions, categories, settings]
  );

  // Import Backup
  const importBackupJson = useCallback(
    (jsonString: string): { success: boolean; error?: string } => {
      try {
        const parsed = JSON.parse(jsonString) as BackupData;
        if (!parsed.apps || !Array.isArray(parsed.apps) || !parsed.wallets || !Array.isArray(parsed.wallets)) {
          return { success: false, error: 'Formato de backup inválido. Chaves esperadas ausentes.' };
        }
        setApps(parsed.apps);
        setWallets(parsed.wallets);
        if (parsed.transactions && Array.isArray(parsed.transactions)) {
          setTransactions(parsed.transactions);
        }
        if (parsed.categories && Array.isArray(parsed.categories)) {
          setCategories(parsed.categories);
        }
        if (parsed.settings) {
          setSettings((prev) => ({ ...prev, ...parsed.settings }));
        }
        if (settings.soundEffects) playSound('success');
        showToast('Backup do CoinBox restaurado com sucesso!');
        return { success: true };
      } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido ao processar JSON';
        return { success: false, error: `Falha ao importar: ${errorMsg}` };
      }
    },
    [settings.soundEffects, showToast]
  );

  // Reset to Factory
  const resetDatabase = useCallback(() => {
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}apps`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}wallets`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}transactions`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}categories`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}settings`);

    setApps(
      DEVICE_INSTALLED_APPS.filter((a) =>
        ['app_free_fire', 'app_roblox', 'app_subway_surfers', 'app_duolingo'].includes(a.id)
      )
    );
    setWallets(INITIAL_WALLETS);
    setTransactions(INITIAL_TRANSACTIONS);
    setCategories(INITIAL_CATEGORIES);
    setSettings(INITIAL_SETTINGS);
    setNavHistory([{ screen: 'home', params: {} }]);
    if (settings.soundEffects) playSound('click');
    showToast('Banco de dados restaurado para as configurações iniciais.');
  }, [settings.soundEffects, showToast]);

  return (
    <CoinBoxContext.Provider
      value={{
        apps,
        installedDeviceApps,
        wallets,
        transactions,
        categories,
        settings,
        currentScreen,
        screenParams,
        simulatedBalances,
        notificationToast,
        navigate,
        goBack,
        showToast,
        toggleFavoriteApp,
        registerAppFromDevice,
        createCustomApp,
        deleteApp,
        createWallet,
        deleteWallet,
        updateWalletRate,
        addBalance,
        removeBalance,
        setSimulatedAmount,
        commitSimulation,
        discardSimulation,
        deleteTransaction,
        clearTransactions,
        addCategory,
        updateSettings,
        togglePremium,
        generateExport,
        importBackupJson,
        resetDatabase,
      }}
    >
      {children}
    </CoinBoxContext.Provider>
  );
};

export const useCoinBox = () => {
  const ctx = useContext(CoinBoxContext);
  if (!ctx) throw new Error('useCoinBox must be used within CoinBoxProvider');
  return ctx;
};
