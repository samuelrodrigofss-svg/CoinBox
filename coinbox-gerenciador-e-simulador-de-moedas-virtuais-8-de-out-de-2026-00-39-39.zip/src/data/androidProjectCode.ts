/**
 * Complete Android Studio Project Source Files
 * Clean Architecture (Presentation, Domain, Data, Local Room, Di, Navigation)
 */

export interface CodeFile {
  path: string;
  language: string;
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: CodeFile[] = [
  {
    path: 'android/build.gradle.kts',
    language: 'kotlin',
    description: 'Root Gradle build file with plugins',
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
}
`,
  },
  {
    path: 'android/app/build.gradle.kts',
    language: 'kotlin',
    description: 'App module Gradle build with Room, Compose, AdMob, Coroutines and Release Signing',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "com.coinbox.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.coinbox.app"
        minSdk = 26 // Android 8.0 Oreo or higher
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        // Room schema export location
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    signingConfigs {
        create("release") {
            // Configured via local.properties or environment variables in CI/CD
            val keystoreFile = System.getenv("KEYSTORE_FILE") ?: "coinbox-release-key.jks"
            storeFile = file(keystoreFile)
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
            keyAlias = System.getenv("KEY_ALIAS") ?: "coinbox"
            keyPassword = System.getenv("KEY_PASSWORD") ?: ""
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)

    // Room Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Kotlin Coroutines
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.core)

    // DataStore Preferences
    implementation(libs.androidx.datastore.preferences)

    // Google Mobile Ads (AdMob)
    implementation(libs.play.services.ads)

    // Hilt Dependency Injection
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.androidx.hilt.navigation.compose)

    // Unit Tests
    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.androidx.room.testing)
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.test.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
}
`,
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    language: 'xml',
    description: 'Android Manifest with non-invasive queries for installed applications and AdMob meta-data',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Official launcher query to inspect installed launchable apps/games safely -->
    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
    </queries>

    <!-- Basic network access strictly for optional AdMob advertisements -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <!-- Local notifications for balance updates -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:name=".CoinBoxApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.CoinBox">

        <!-- Google AdMob Sample App ID for testing -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.CoinBox">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
  },
  {
    path: 'android/app/src/main/java/com/coinbox/app/data/local/entity/Entities.kt',
    language: 'kotlin',
    description: 'Room Database Entities (AppEntity, WalletEntity, TransactionEntity, CategoryEntity, SettingsEntity)',
    content: `package com.coinbox.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "apps",
    indices = [Index(value = ["packageName"], unique = true)]
)
data class AppEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val iconReference: String,
    val category: String,
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "wallets",
    foreignKeys = [
        ForeignKey(
            entity = AppEntity::class,
            parentColumns = ["id"],
            childColumns = ["appId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["appId"])]
)
data class WalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appId: Long,
    val name: String,
    val currencyType: String, // "Moedas", "Gemas", "Diamantes", etc.
    val balance: Double,
    val exchangeRateToBrl: Double = 0.01,
    val color: String = "#06b6d4",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = WalletEntity::class,
            parentColumns = ["id"],
            childColumns = ["walletId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["walletId"])]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val walletId: Long,
    val type: String, // "CREDIT", "DEBIT", "SIMULATION_APPLY"
    val amount: Double,
    val previousBalance: Double,
    val newBalance: Double,
    val description: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val darkMode: Boolean = true,
    val notifications: Boolean = true,
    val currency: String = "R$",
    val simulationMode: Boolean = false,
    val allowNegativeBalance: Boolean = false,
    val isPremium: Boolean = false
)
`,
  },
  {
    path: 'android/app/src/main/java/com/coinbox/app/data/local/dao/Daos.kt',
    language: 'kotlin',
    description: 'Room DAOs with Kotlin Coroutines and StateFlow',
    content: `package com.coinbox.app.data.local.dao

import androidx.room.*
import com.coinbox.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM apps ORDER BY favorite DESC, appName ASC")
    fun getAllApps(): Flow<List<AppEntity>>

    @Query("SELECT * FROM apps WHERE id = :id")
    suspend fun getAppById(id: Long): AppEntity?

    @Query("SELECT * FROM apps WHERE favorite = 1")
    fun getFavoriteApps(): Flow<List<AppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: AppEntity): Long

    @Update
    suspend fun updateApp(app: AppEntity)

    @Delete
    suspend fun deleteApp(app: AppEntity)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets WHERE appId = :appId ORDER BY createdAt ASC")
    fun getWalletsByApp(appId: Long): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets ORDER BY balance DESC")
    fun getAllWallets(): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets WHERE id = :walletId")
    suspend fun getWalletById(walletId: Long): WalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: WalletEntity): Long

    @Update
    suspend fun updateWallet(wallet: WalletEntity)

    @Delete
    suspend fun deleteWallet(wallet: WalletEntity)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE walletId = :walletId ORDER BY createdAt DESC")
    fun getTransactionsByWallet(walletId: Long): Flow<List<TransactionEntity>>

    @Insert
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryEntity): Long
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE id = 1")
    fun getSettings(): Flow<SettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateSettings(settings: SettingsEntity)
}
`,
  },
  {
    path: 'android/app/src/main/java/com/coinbox/app/data/local/database/CoinBoxDatabase.kt',
    language: 'kotlin',
    description: 'Room Database definition with thread-safe singleton & migrations',
    content: `package com.coinbox.app.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.coinbox.app.data.local.dao.*
import com.coinbox.app.data.local.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        AppEntity::class,
        WalletEntity::class,
        TransactionEntity::class,
        CategoryEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class CoinBoxDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao
    abstract fun walletDao(): WalletDao
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: CoinBoxDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): CoinBoxDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CoinBoxDatabase::class.java,
                    "coinbox_database"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        // Seed default categories
                        val catDao = database.categoryDao()
                        catDao.insertCategory(CategoryEntity(name = "Jogos", icon = "🎮"))
                        catDao.insertCategory(CategoryEntity(name = "Aplicativos", icon = "📱"))
                        catDao.insertCategory(CategoryEntity(name = "Trabalho", icon = "💼"))
                        catDao.insertCategory(CategoryEntity(name = "Outros", icon = "🎯"))

                        // Seed default settings
                        database.settingsDao().updateSettings(SettingsEntity())
                    }
                }
            }
        }
    }
}
`,
  },
  {
    path: 'android/app/src/main/java/com/coinbox/app/domain/usecase/BalanceUseCases.kt',
    language: 'kotlin',
    description: 'Clean Architecture Use Cases for Adding, Removing and Simulating Balances',
    content: `package com.coinbox.app.domain.usecase

import com.coinbox.app.data.local.dao.TransactionDao
import com.coinbox.app.data.local.dao.WalletDao
import com.coinbox.app.data.local.entity.TransactionEntity
import com.coinbox.app.data.local.entity.WalletEntity
import javax.inject.Inject

class AddBalanceUseCase @Inject constructor(
    private val walletDao: WalletDao,
    private val transactionDao: TransactionDao
) {
    suspend operator fun invoke(walletId: Long, amount: Double, description: String): Result<WalletEntity> {
        if (amount <= 0.0) {
            return Result.failure(IllegalArgumentException("A quantidade deve ser maior que zero."))
        }
        val wallet = walletDao.getWalletById(walletId)
            ?: return Result.failure(IllegalStateException("Carteira não encontrada."))

        val previousBalance = wallet.balance
        val newBalance = previousBalance + amount
        val updatedWallet = wallet.copy(
            balance = newBalance,
            updatedAt = System.currentTimeMillis()
        )

        walletDao.updateWallet(updatedWallet)
        transactionDao.insertTransaction(
            TransactionEntity(
                walletId = walletId,
                type = "CREDIT",
                amount = amount,
                previousBalance = previousBalance,
                newBalance = newBalance,
                description = description.ifBlank { "Adição de saldo" }
            )
        )
        return Result.success(updatedWallet)
    }
}

class RemoveBalanceUseCase @Inject constructor(
    private val walletDao: WalletDao,
    private val transactionDao: TransactionDao
) {
    suspend operator fun invoke(
        walletId: Long,
        amount: Double,
        allowNegative: Boolean,
        description: String
    ): Result<WalletEntity> {
        if (amount <= 0.0) {
            return Result.failure(IllegalArgumentException("A quantidade deve ser maior que zero."))
        }
        val wallet = walletDao.getWalletById(walletId)
            ?: return Result.failure(IllegalStateException("Carteira não encontrada."))

        val previousBalance = wallet.balance
        val newBalance = previousBalance - amount

        if (newBalance < 0 && !allowNegative) {
            return Result.failure(IllegalStateException("Saldo insuficiente. Saldo atual: $previousBalance."))
        }

        val updatedWallet = wallet.copy(
            balance = newBalance,
            updatedAt = System.currentTimeMillis()
        )

        walletDao.updateWallet(updatedWallet)
        transactionDao.insertTransaction(
            TransactionEntity(
                walletId = walletId,
                type = "DEBIT",
                amount = amount,
                previousBalance = previousBalance,
                newBalance = newBalance,
                description = description.ifBlank { "Resgate de saldo" }
            )
        )
        return Result.success(updatedWallet)
    }
}
`,
  },
  {
    path: 'android/app/src/main/java/com/coinbox/app/presentation/screens/HomeScreen.kt',
    language: 'kotlin',
    description: 'Jetpack Compose Material 3 Home Screen matching UI spec',
    content: `package com.coinbox.app.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.coinbox.app.presentation.viewmodel.CoinBoxViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CoinBoxViewModel,
    onNavigateToApps: () -> Unit,
    onNavigateToAddApp: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAppDetail: (Long) -> Unit
) {
    val apps by viewModel.apps.collectAsState(initial = emptyList())
    val wallets by viewModel.wallets.collectAsState(initial = emptyList())
    val transactions by viewModel.transactions.collectAsState(initial = emptyList())

    val totalBalanceBrl = wallets.sumOf { it.balance * it.exchangeRateToBrl }
    val totalUnits = wallets.sumOf { it.balance }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🪙", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CoinBox", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Configurações")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Hero Balance Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("SALDO TOTAL ESTIMADO", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "R$ " + "%.2f".format(totalBalanceBrl),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Total de $totalUnits unidades virtuais",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // 4 Buttons from prompt 3
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Button(onClick = onNavigateToApps) { Text("Meus Apps") }
                            OutlinedButton(onClick = onNavigateToAddApp) { Text("+ Adicionar") }
                            IconButton(onClick = onNavigateToHistory) { Icon(Icons.Default.History, "Histórico") }
                        }
                    }
                }
            }

            // Registered apps section
            item {
                Text("Meus Aplicativos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            items(apps) { app ->
                Card(
                    onClick = { onNavigateToAppDetail(app.id) },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🎮", fontSize = 28.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(app.appName, fontWeight = FontWeight.Bold)
                            Text(app.category, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}
`,
  },
  {
    path: 'android/app/src/test/java/com/coinbox/app/CoinBoxUnitTest.kt',
    language: 'kotlin',
    description: 'Unit Tests for Balance addition, subtraction, negative balance prevention & simulation',
    content: `package com.coinbox.app

import com.coinbox.app.data.local.dao.TransactionDao
import com.coinbox.app.data.local.dao.WalletDao
import com.coinbox.app.data.local.entity.WalletEntity
import com.coinbox.app.domain.usecase.AddBalanceUseCase
import com.coinbox.app.domain.usecase.RemoveBalanceUseCase
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.*

class CoinBoxUnitTest {

    private lateinit var walletDao: WalletDao
    private lateinit var transactionDao: TransactionDao
    private lateinit var addBalanceUseCase: AddBalanceUseCase
    private lateinit var removeBalanceUseCase: RemoveBalanceUseCase

    @Before
    fun setUp() {
        walletDao = mock(WalletDao::class.java)
        transactionDao = mock(TransactionDao::class.java)
        addBalanceUseCase = AddBalanceUseCase(walletDao, transactionDao)
        removeBalanceUseCase = RemoveBalanceUseCase(walletDao, transactionDao)
    }

    @Test
    fun testAddBalance_Success() = runBlocking {
        val testWallet = WalletEntity(id = 1L, appId = 1L, name = "Diamantes", currencyType = "Gemas", balance = 5000.0)
        \`when\`(walletDao.getWalletById(1L)).thenReturn(testWallet)

        val result = addBalanceUseCase(1L, 10000.0, "Evento")
        assertTrue(result.isSuccess)
        assertEquals(15000.0, result.getOrNull()?.balance ?: 0.0, 0.001)
    }

    @Test
    fun testRemoveBalance_PreventsNegative_WhenDisabled() = runBlocking {
        val testWallet = WalletEntity(id = 1L, appId = 1L, name = "Diamantes", currencyType = "Gemas", balance = 500.0)
        \`when\`(walletDao.getWalletById(1L)).thenReturn(testWallet)

        val result = removeBalanceUseCase(1L, 1000.0, allowNegative = false, description = "Compra")
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("Saldo insuficiente") == true)
    }

    @Test
    fun testRemoveBalance_AllowsNegative_WhenExplicitlyEnabled() = runBlocking {
        val testWallet = WalletEntity(id = 1L, appId = 1L, name = "Diamantes", currencyType = "Gemas", balance = 500.0)
        \`when\`(walletDao.getWalletById(1L)).thenReturn(testWallet)

        val result = removeBalanceUseCase(1L, 1000.0, allowNegative = true, description = "Empréstimo")
        assertTrue(result.isSuccess)
        assertEquals(-500.0, result.getOrNull()?.balance ?: 0.0, 0.001)
    }
}
`,
  },
];
