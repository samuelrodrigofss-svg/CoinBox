import { AppItem, WalletItem, TransactionItem, CategoryItem, SettingsState } from '../types/coinbox';

export const INITIAL_CATEGORIES: CategoryItem[] = [
  { id: 'cat_games', name: 'Jogos', icon: '🎮', createdAt: new Date().toISOString() },
  { id: 'cat_apps', name: 'Aplicativos', icon: '📱', createdAt: new Date().toISOString() },
  { id: 'cat_work', name: 'Trabalho', icon: '💼', createdAt: new Date().toISOString() },
  { id: 'cat_other', name: 'Outros', icon: '🎯', createdAt: new Date().toISOString() },
];

export const INITIAL_SETTINGS: SettingsState = {
  darkMode: true,
  notifications: true,
  currencySymbol: 'R$',
  allowNegativeBalance: false,
  simulationModeEnabled: false,
  soundEffects: true,
  isPremium: false,
  showAdMobBanner: true,
  hasCompletedOnboarding: false,
};

// Realistic installed Android apps list to detect/populate
export const DEVICE_INSTALLED_APPS: AppItem[] = [
  {
    id: 'app_free_fire',
    packageName: 'com.dts.freefireth',
    appName: 'Free Fire MAX',
    iconReference: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=128&auto=format&fit=crop&q=80',
    category: 'Jogos',
    favorite: true,
    isInstalled: true,
    versionName: '2.104.1',
    createdAt: '2026-10-01T10:00:00Z',
    updatedAt: '2026-10-07T14:30:00Z',
  },
  {
    id: 'app_roblox',
    packageName: 'com.roblox.client',
    appName: 'Roblox',
    iconReference: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=128&auto=format&fit=crop&q=80',
    category: 'Jogos',
    favorite: true,
    isInstalled: true,
    versionName: '2.640.480',
    createdAt: '2026-10-02T12:00:00Z',
    updatedAt: '2026-10-07T12:00:00Z',
  },
  {
    id: 'app_subway_surfers',
    packageName: 'com.kiloo.subwaysurf',
    appName: 'Subway Surfers',
    iconReference: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=128&auto=format&fit=crop&q=80',
    category: 'Jogos',
    favorite: false,
    isInstalled: true,
    versionName: '3.25.0',
    createdAt: '2026-10-03T15:00:00Z',
    updatedAt: '2026-10-07T16:00:00Z',
  },
  {
    id: 'app_brawl_stars',
    packageName: 'com.supercell.brawlstars',
    appName: 'Brawl Stars',
    iconReference: 'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd?w=128&auto=format&fit=crop&q=80',
    category: 'Jogos',
    favorite: true,
    isInstalled: true,
    versionName: '57.325',
    createdAt: '2026-10-04T09:00:00Z',
    updatedAt: '2026-10-07T18:00:00Z',
  },
  {
    id: 'app_clash_royale',
    packageName: 'com.supercell.clashroyale',
    appName: 'Clash Royale',
    iconReference: 'https://images.unsplash.com/photo-1612287233215-d7256157053e?w=128&auto=format&fit=crop&q=80',
    category: 'Jogos',
    favorite: false,
    isInstalled: true,
    versionName: '4.218.1',
    createdAt: '2026-10-05T11:20:00Z',
    updatedAt: '2026-10-07T19:10:00Z',
  },
  {
    id: 'app_duolingo',
    packageName: 'com.duolingo',
    appName: 'Duolingo',
    iconReference: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=128&auto=format&fit=crop&q=80',
    category: 'Aplicativos',
    favorite: true,
    isInstalled: true,
    versionName: '6.12.0',
    createdAt: '2026-10-05T14:00:00Z',
    updatedAt: '2026-10-07T10:00:00Z',
  },
  {
    id: 'app_tiktok',
    packageName: 'com.zhiliaoapp.musically',
    appName: 'TikTok',
    iconReference: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=128&auto=format&fit=crop&q=80',
    category: 'Aplicativos',
    favorite: false,
    isInstalled: true,
    versionName: '34.8.1',
    createdAt: '2026-10-06T08:30:00Z',
    updatedAt: '2026-10-07T11:45:00Z',
  },
  {
    id: 'app_genshin',
    packageName: 'com.miHoYo.GenshinImpact',
    appName: 'Genshin Impact',
    iconReference: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=128&auto=format&fit=crop&q=80',
    category: 'Jogos',
    favorite: false,
    isInstalled: true,
    versionName: '5.1.0',
    createdAt: '2026-10-06T18:00:00Z',
    updatedAt: '2026-10-07T09:00:00Z',
  },
  {
    id: 'app_notion',
    packageName: 'notion.id',
    appName: 'Notion Workspace',
    iconReference: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=128&auto=format&fit=crop&q=80',
    category: 'Trabalho',
    favorite: false,
    isInstalled: true,
    versionName: '0.6.14',
    createdAt: '2026-10-06T20:00:00Z',
    updatedAt: '2026-10-07T08:30:00Z',
  },
];

export const INITIAL_WALLETS: WalletItem[] = [
  // Free Fire
  {
    id: 'w_ff_diamonds',
    appId: 'app_free_fire',
    name: 'Diamantes',
    currencyType: 'Diamantes',
    icon: '💎',
    balance: 10450,
    exchangeRateToBrl: 0.04, // 1 Diamante ~ R$0.04
    color: '#06b6d4',
    createdAt: '2026-10-01T10:05:00Z',
    updatedAt: '2026-10-07T14:30:00Z',
  },
  {
    id: 'w_ff_gold',
    appId: 'app_free_fire',
    name: 'Moedas de Ouro',
    currencyType: 'Moedas',
    icon: '🪙',
    balance: 45200,
    exchangeRateToBrl: 0.0005,
    color: '#eab308',
    createdAt: '2026-10-01T10:05:00Z',
    updatedAt: '2026-10-07T14:30:00Z',
  },
  // Roblox
  {
    id: 'w_rbx_robux',
    appId: 'app_roblox',
    name: 'Robux',
    currencyType: 'Moedas',
    icon: '🪙',
    balance: 8500,
    exchangeRateToBrl: 0.055,
    color: '#10b981',
    createdAt: '2026-10-02T12:05:00Z',
    updatedAt: '2026-10-07T12:00:00Z',
  },
  // Subway Surfers
  {
    id: 'w_subway_coins',
    appId: 'app_subway_surfers',
    name: 'Moedas',
    currencyType: 'Moedas',
    icon: '🪙',
    balance: 78000,
    exchangeRateToBrl: 0.0001,
    color: '#f59e0b',
    createdAt: '2026-10-03T15:10:00Z',
    updatedAt: '2026-10-07T16:00:00Z',
  },
  {
    id: 'w_subway_keys',
    appId: 'app_subway_surfers',
    name: 'Chaves / Vidas',
    currencyType: 'Vidas',
    icon: '🔑',
    balance: 99,
    exchangeRateToBrl: 0.20,
    color: '#ec4899',
    createdAt: '2026-10-03T15:10:00Z',
    updatedAt: '2026-10-07T16:00:00Z',
  },
  // Duolingo
  {
    id: 'w_duo_gems',
    appId: 'app_duolingo',
    name: 'Gemas de Estudo',
    currencyType: 'Gemas',
    icon: '💎',
    balance: 3200,
    exchangeRateToBrl: 0.01,
    color: '#3b82f6',
    createdAt: '2026-10-05T14:10:00Z',
    updatedAt: '2026-10-07T10:00:00Z',
  },
  {
    id: 'w_duo_xp',
    appId: 'app_duolingo',
    name: 'Pontos XP',
    currencyType: 'Pontos',
    icon: '⭐',
    balance: 50000,
    exchangeRateToBrl: 0.001,
    color: '#8b5cf6',
    createdAt: '2026-10-05T14:10:00Z',
    updatedAt: '2026-10-07T10:00:00Z',
  },
];

export const INITIAL_TRANSACTIONS: TransactionItem[] = [
  {
    id: 'tx_1',
    walletId: 'w_ff_diamonds',
    appId: 'app_free_fire',
    appName: 'Free Fire MAX',
    walletName: 'Diamantes',
    currencyIcon: '💎',
    type: 'CREDIT',
    amount: 5000,
    previousBalance: 5450,
    newBalance: 10450,
    description: 'Recompensa de evento passe de elite e farm semanal',
    createdAt: '2026-10-07T14:30:00Z',
  },
  {
    id: 'tx_2',
    walletId: 'w_rbx_robux',
    appId: 'app_roblox',
    appName: 'Roblox',
    walletName: 'Robux',
    currencyIcon: '🪙',
    type: 'CREDIT',
    amount: 2500,
    previousBalance: 6000,
    newBalance: 8500,
    description: 'Simulação de venda de passe de criação',
    createdAt: '2026-10-07T12:00:00Z',
  },
  {
    id: 'tx_3',
    walletId: 'w_subway_keys',
    appId: 'app_subway_surfers',
    appName: 'Subway Surfers',
    walletName: 'Chaves / Vidas',
    currencyIcon: '🔑',
    type: 'DEBIT',
    amount: 15,
    previousBalance: 114,
    newBalance: 99,
    description: 'Uso de chaves para reviver no recorde mundial',
    createdAt: '2026-10-07T08:15:00Z',
  },
  {
    id: 'tx_4',
    walletId: 'w_duo_xp',
    appId: 'app_duolingo',
    appName: 'Duolingo',
    walletName: 'Pontos XP',
    currencyIcon: '⭐',
    type: 'CREDIT',
    amount: 1200,
    previousBalance: 48800,
    newBalance: 50000,
    description: 'Ofensiva de 100 dias completada com perfeição',
    createdAt: '2026-10-06T21:40:00Z',
  },
];

// Web Audio API beep generator for tactile feel
export function playSound(type: 'click' | 'credit' | 'debit' | 'error' | 'success') {
  if (typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (type === 'click') {
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.05);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === 'credit') {
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.start(now);
      osc.stop(now + 0.12);
    } else if (type === 'debit') {
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.exponentialRampToValueAtTime(320, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'error') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.setValueAtTime(180, now + 0.08);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
      osc.start(now);
      osc.stop(now + 0.16);
    } else if (type === 'success') {
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.08);
      osc.frequency.setValueAtTime(783.99, now + 0.16);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.start(now);
      osc.stop(now + 0.28);
    }
  } catch {
    // Ignore audio permission or context restrictions
  }
}
