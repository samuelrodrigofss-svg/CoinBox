package com.coinbox.app.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.coinbox.app.data.local.entity.*
import com.coinbox.app.domain.repository.CoinBoxRepository
import com.coinbox.app.domain.usecase.AddBalanceUseCase
import com.coinbox.app.domain.usecase.RemoveBalanceUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CoinBoxViewModel @Inject constructor(
    private val repository: CoinBoxRepository,
    private val addBalanceUseCase: AddBalanceUseCase,
    private val removeBalanceUseCase: RemoveBalanceUseCase
) : ViewModel() {

    val apps: StateFlow<List<AppEntity>> = repository.getAllApps()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val wallets: StateFlow<List<WalletEntity>> = repository.getAllWallets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<CategoryEntity>> = repository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<SettingsEntity?> = repository.getSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _simulatedBalances = MutableStateFlow<Map<Long, Double>>(emptyMap())
    val simulatedBalances: StateFlow<Map<Long, Double>> = _simulatedBalances.asStateFlow()

    fun toggleFavorite(app: AppEntity) {
        viewModelScope.launch {
            repository.updateApp(app.copy(favorite = !app.favorite, updatedAt = System.currentTimeMillis()))
        }
    }

    fun addApp(appName: String, packageName: String, category: String, icon: String) {
        viewModelScope.launch {
            val appId = repository.insertApp(
                AppEntity(
                    appName = appName,
                    packageName = packageName,
                    category = category,
                    iconReference = icon
                )
            )
            // Seed a starter wallet
            repository.insertWallet(
                WalletEntity(
                    appId = appId,
                    name = "Moedas",
                    currencyType = "Moedas",
                    balance = 1000.0
                )
            )
        }
    }

    fun addWallet(appId: Long, name: String, currencyType: String, initialBalance: Double, rate: Double) {
        viewModelScope.launch {
            val walletId = repository.insertWallet(
                WalletEntity(
                    appId = appId,
                    name = name,
                    currencyType = currencyType,
                    balance = initialBalance,
                    exchangeRateToBrl = rate
                )
            )
            if (initialBalance > 0.0) {
                repository.insertTransaction(
                    TransactionEntity(
                        walletId = walletId,
                        type = "CREDIT",
                        amount = initialBalance,
                        previousBalance = 0.0,
                        newBalance = initialBalance,
                        description = "Criação de carteira com saldo inicial"
                    )
                )
            }
        }
    }

    fun addBalance(walletId: Long, amount: Double, description: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = addBalanceUseCase(walletId, amount, description)
            if (result.isSuccess) {
                onResult(true, "Saldo adicionado com sucesso!")
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Erro ao adicionar saldo")
            }
        }
    }

    fun removeBalance(walletId: Long, amount: Double, description: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val allowNegative = settings.value?.allowNegativeBalance ?: false
            val result = removeBalanceUseCase(walletId, amount, allowNegative, description)
            if (result.isSuccess) {
                onResult(true, "Saldo resgatado com sucesso!")
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Erro ao resgatar saldo")
            }
        }
    }

    fun setSimulation(walletId: Long, targetBalance: Double) {
        val current = _simulatedBalances.value.toMutableMap()
        current[walletId] = targetBalance
        _simulatedBalances.value = current
    }

    fun commitSimulation(walletId: Long) {
        viewModelScope.launch {
            val simulated = _simulatedBalances.value[walletId] ?: return@launch
            val wallet = repository.getWalletById(walletId) ?: return@launch
            val prev = wallet.balance
            repository.updateWallet(wallet.copy(balance = simulated, updatedAt = System.currentTimeMillis()))
            repository.insertTransaction(
                TransactionEntity(
                    walletId = walletId,
                    type = "SIMULATION_APPLY",
                    amount = Math.abs(simulated - prev),
                    previousBalance = prev,
                    newBalance = simulated,
                    description = "Simulação aplicada no saldo real"
                )
            )
            discardSimulation(walletId)
        }
    }

    fun discardSimulation(walletId: Long) {
        val current = _simulatedBalances.value.toMutableMap()
        current.remove(walletId)
        _simulatedBalances.value = current
    }
}
