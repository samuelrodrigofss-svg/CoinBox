package com.coinbox.app

import android.app.Application
import com.google.android.gms.ads.MobileAds
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * CoinBox Android Application Entry Point
 * Initializes AdMob SDK and Local Room storage
 */
@HiltAndroidApp
class CoinBoxApplication : Application() {

    private val applicationScope = CoroutineScope(Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        // Initialize Google Mobile Ads (AdMob) safely on background thread
        applicationScope.launch {
            MobileAds.initialize(this@CoinBoxApplication) {}
        }
    }
}
