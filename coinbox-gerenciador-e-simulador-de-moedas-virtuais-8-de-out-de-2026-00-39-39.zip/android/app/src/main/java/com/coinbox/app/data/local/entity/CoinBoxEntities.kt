package com.coinbox.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entidade de Aplicativo no Banco Room
 * Armazena informações dos aplicativos detectados ou cadastrados pelo usuário.
 */
@Entity(
    tableName = "apps",
    indices = [Index(value = ["packageName"], unique = true)]
)
data class AppEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val appName: String,
    val iconReference: String,
    val category: String, // "Jogos", "Aplicativos", "Trabalho", "Outros"
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Entidade de Carteira Virtual no Banco Room
 * Cada aplicativo pode conter múltiplas carteiras (ex: Moedas, Gemas, Diamantes, Vidas).
 */
@Entity(
    tableName = "wallets",
    foreignKeys = [
        ForeignKey(
            entity = AppEntity::class,
            parentColumns = ["id"],
            childColumns = ["appId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["appId"])]
)
data class WalletEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val appId: Long,
    val name: String,
    val currencyType: String, // Moedas, Gemas, Diamantes, Pontos, Fichas, Vidas, etc.
    val balance: Double = 0.0,
    val exchangeRateToBrl: Double = 0.01, // Estimativa de conversão
    val color: String = "#06b6d4",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Entidade de Transação / Livro-Razão no Banco Room
 * Registra cada adição, resgate ou aplicação de simulação de saldo.
 */
@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = WalletEntity::class,
            parentColumns = ["id"],
            childColumns = ["walletId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["walletId"])]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val walletId: Long,
    val type: String, // "CREDIT", "DEBIT", "SIMULATION_APPLY"
    val amount: Double,
    val previousBalance: Double,
    val newBalance: Double,
    val description: String,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Entidade de Categorias
 */
@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val icon: String,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Entidade de Configurações do CoinBox
 */
@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val darkMode: Boolean = true,
    val notifications: Boolean = true,
    val currency: String = "R$",
    val simulationMode: Boolean = false,
    val allowNegativeBalance: Boolean = false,
    val isPremium: Boolean = false
)
