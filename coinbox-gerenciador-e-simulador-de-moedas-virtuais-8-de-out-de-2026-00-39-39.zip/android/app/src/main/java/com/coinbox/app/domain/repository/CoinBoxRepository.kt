package com.coinbox.app.domain.repository

import com.coinbox.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

interface CoinBoxRepository {
    fun getAllApps(): Flow<List<AppEntity>>
    suspend fun getAppById(id: Long): AppEntity?
    suspend fun insertApp(app: AppEntity): Long
    suspend fun updateApp(app: AppEntity)
    suspend fun deleteApp(app: AppEntity)

    fun getWalletsByApp(appId: Long): Flow<List<WalletEntity>>
    fun getAllWallets(): Flow<List<WalletEntity>>
    suspend fun getWalletById(walletId: Long): WalletEntity?
    suspend fun insertWallet(wallet: WalletEntity): Long
    suspend fun updateWallet(wallet: WalletEntity)
    suspend fun deleteWallet(wallet: WalletEntity)

    fun getAllTransactions(): Flow<List<TransactionEntity>>
    suspend fun insertTransaction(transaction: TransactionEntity): Long
    suspend fun deleteTransaction(transaction: TransactionEntity)
    suspend fun clearTransactions()

    fun getAllCategories(): Flow<List<CategoryEntity>>
    suspend fun insertCategory(category: CategoryEntity): Long

    fun getSettings(): Flow<SettingsEntity?>
    suspend fun updateSettings(settings: SettingsEntity)
}
