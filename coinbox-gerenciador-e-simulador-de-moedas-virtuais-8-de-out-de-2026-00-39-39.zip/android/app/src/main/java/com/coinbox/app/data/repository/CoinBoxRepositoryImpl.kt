package com.coinbox.app.data.repository

import com.coinbox.app.data.local.dao.*
import com.coinbox.app.data.local.entity.*
import com.coinbox.app.domain.repository.CoinBoxRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CoinBoxRepositoryImpl @Inject constructor(
    private val appDao: AppDao,
    private val walletDao: WalletDao,
    private val transactionDao: TransactionDao,
    private val categoryDao: CategoryDao,
    private val settingsDao: SettingsDao
) : CoinBoxRepository {

    override fun getAllApps(): Flow<List<AppEntity>> = appDao.getAllApps()
    override suspend fun getAppById(id: Long): AppEntity? = appDao.getAppById(id)
    override suspend fun insertApp(app: AppEntity): Long = appDao.insertApp(app)
    override suspend fun updateApp(app: AppEntity) = appDao.updateApp(app)
    override suspend fun deleteApp(app: AppEntity) = appDao.deleteApp(app)

    override fun getWalletsByApp(appId: Long): Flow<List<WalletEntity>> = walletDao.getWalletsByApp(appId)
    override fun getAllWallets(): Flow<List<WalletEntity>> = walletDao.getAllWallets()
    override suspend fun getWalletById(walletId: Long): WalletEntity? = walletDao.getWalletById(walletId)
    override suspend fun insertWallet(wallet: WalletEntity): Long = walletDao.insertWallet(wallet)
    override suspend fun updateWallet(wallet: WalletEntity) = walletDao.updateWallet(wallet)
    override suspend fun deleteWallet(wallet: WalletEntity) = walletDao.deleteWallet(wallet)

    override fun getAllTransactions(): Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    override suspend fun insertTransaction(transaction: TransactionEntity): Long = transactionDao.insertTransaction(transaction)
    override suspend fun deleteTransaction(transaction: TransactionEntity) = transactionDao.deleteTransaction(transaction)
    override suspend fun clearTransactions() = transactionDao.clearAll()

    override fun getAllCategories(): Flow<List<CategoryEntity>> = categoryDao.getAllCategories()
    override suspend fun insertCategory(category: CategoryEntity): Long = categoryDao.insertCategory(category)

    override fun getSettings(): Flow<SettingsEntity?> = settingsDao.getSettings()
    override suspend fun updateSettings(settings: SettingsEntity) = settingsDao.updateSettings(settings)
}
