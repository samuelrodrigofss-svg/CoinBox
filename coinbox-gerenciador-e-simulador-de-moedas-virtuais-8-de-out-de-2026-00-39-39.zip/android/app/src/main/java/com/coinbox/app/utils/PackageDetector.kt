package com.coinbox.app.utils

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.coinbox.app.data.local.entity.AppEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Utilitário oficial para detecção de aplicativos instalados no aparelho.
 * Respeita 100% as diretrizes da Google Play e a privacidade do usuário,
 * utilizando apenas a Intent CATEGORY_LAUNCHER sem permissões de acessibilidade invasivas ou root.
 */
object PackageDetector {

    suspend fun getInstalledLaunchableApps(context: Context): List<AppEntity> = withContext(Dispatchers.IO) {
        val packageManager = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfoList = packageManager.queryIntentActivities(intent, 0)
        val appList = mutableListOf<AppEntity>()

        for (resolveInfo in resolveInfoList) {
            val appInfo = resolveInfo.activityInfo.applicationInfo
            val packageName = appInfo.packageName

            // Ignorar o próprio CoinBox
            if (packageName == context.packageName) continue

            val appName = resolveInfo.loadLabel(packageManager).toString()
            val isGame = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                false
            }

            val category = if (isGame) "Jogos" else "Aplicativos"

            appList.add(
                AppEntity(
                    packageName = packageName,
                    appName = appName,
                    iconReference = "android.resource://$packageName/${appInfo.icon}",
                    category = category,
                    favorite = false
                )
            )
        }

        appList.sortedBy { it.appName }
    }
}
